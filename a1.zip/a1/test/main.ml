open OUnit2
open Enigma

(** [index_test name input expected_output] constructs an OUnit test
    named [name] that asserts the quality of [expected_output] with
    [index input]. *)
let index_test (name : string) (input : char) (expected_output : int) :
    test =
  name >:: fun _ ->
  (* the [printer] tells OUnit how to convert the output to a string *)
  assert_equal expected_output (index input) ~printer:string_of_int

(* You will find it helpful to write functions like [make_index_test]
   for each of the other functions you are testing. They will keep your
   lists of tests below very readable, and will also help you to avoid
   repeating code. You will also find it helpful to create [~printer]
   functions for the data types in use. *)

let index_tests =
  [
    index_test "index of A is 0" 'A' 0;
    index_test "index of B is 1" 'B' 1;
    index_test "index of Z is 25" 'Z' 25;
    index_test "index of C is 2" 'C' 2;
    index_test "index of D is 3" 'D' 3;
  ]

let map_rl_test
    (name : string)
    (wiring : string)
    (top_letter : char)
    (input : int)
    (expected_output : int) : test =
  name >:: fun _ ->
  assert_equal expected_output
    (map_r_to_l wiring top_letter input)
    ~printer:string_of_int

let map_rl_tests =
  [
    map_rl_test
      "Alphabet wiring with top_letter A that results in no net change"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 'A' 0 0;
    map_rl_test
      "A1 wiring example with top_letter C that results in no net \
       change"
      "BACDEFGHIJKLMNOPQRSTUVWXYZ" 'C' 0 0;
    map_rl_test
      "Reflector C wiring example with top_letter E that results in \
       net change from the input to the output"
      "FVPJIAOYEDRZXWGCTKUQSBNMHL" 'E' 2 10;
    map_rl_test
      "Rotor III wiring example with top_letter O that results in net \
       change from the input to the output"
      "BDFHJLCPRTXVZNYEIWGAKMUSQO" 'O' 14 17;
    map_rl_test
      "A1 wiring example with top_letter A that results in net change \
       from the input to the output"
      "BACDEFGHIJKLMNOPQRSTUVWXYZ" 'A' 0 1;
  ]

let map_lr_test
    (name : string)
    (wiring : string)
    (top_letter : char)
    (input : int)
    (expected_output : int) : test =
  name >:: fun _ ->
  assert_equal expected_output
    (map_l_to_r wiring top_letter input)
    ~printer:string_of_int

let map_lr_tests =
  [
    map_lr_test
      "Alphabet wiring with top_letter A that results in no net change"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 'A' 0 0;
    map_lr_test
      "Alphabet wiring with top_letter C that results in no net change"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 'C' 0 0;
    map_lr_test
      "A1 wiring example with top_letter F that results in net change \
       from the input value to the output value"
      "EKMFLGDQVZNTOWYHXUSPAIBRCJ" 'F' 10 14;
    map_lr_test
      "A1 wiring example with top_letter A that results in net change \
       from the input value to the output value"
      "EKMFLGDQVZNTOWYHXUSPAIBRCJ" 'A' 0 20;
    map_lr_test
      "Reflector C wiring example with top_letter D that results in \
       net change from the input value to the output value"
      "FVPJIAOYEDRZXWGCTKUQSBNMHL" 'D' 13 16;
  ]

let map_refl_test
    (name : string)
    (wiring : string)
    (input : int)
    (expected_output : int) : test =
  name >:: fun _ ->
  assert_equal expected_output (map_refl wiring input)
    ~printer:string_of_int

let map_refl_tests =
  [
    map_refl_test
      "Alphabet reflector that has no net change on the input"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 0 0;
    map_refl_test
      "Non-Alphabet reflector B that changes the input to a different \
       value"
      "YRUHQSLDPXNGOKMIEBFZCWVJAT" 0 24;
    map_refl_test
      "Reflected version of the previous test on the non-alphabet \
       reflector that changes the input to a different value, which \
       ends up being the original value inputed in the test before"
      "YRUHQSLDPXNGOKMIEBFZCWVJAT" 24 0;
    map_refl_test
      "Non-Alphabet reflector C that changes the input to a different \
       value"
      "FVPJIAOYEDRZXWGCTKUQSBNMHL" 0 5;
    map_refl_test
      "Reflected version of the previous test on the non-alphabet \
       reflector that changes the input to a different value, which \
       ends up being the original value inputed in the test before"
      "FVPJIAOYEDRZXWGCTKUQSBNMHL" 5 0;
  ]

let map_plug_test
    (name : string)
    (plugs : (char * char) list)
    (c : char)
    (expected_output : char) : test =
  name >:: fun _ ->
  assert_equal expected_output (map_plug plugs c)
    ~printer:(String.make 1)

let map_plug_tests =
  [
    map_plug_test "Empty plugboard which results in no net change" []
      'A' 'A';
    map_plug_test
      "Plugboard that converts two letters to two other letters. This \
       test case allows the input to convert. Example given in A1"
      [ ('A', 'Z'); ('X', 'Y') ]
      'A' 'Z';
    map_plug_test
      "Plugboard that utilizes the third item in the plugboard list to \
       convert a letter into another letter."
      [ ('A', 'Z'); ('X', 'Y'); ('T', 'B') ]
      'T' 'B';
    map_plug_test
      "Plugboard that utilizes the second item in the plugboard list \
       to convert a letter into another letter."
      [ ('A', 'Z'); ('X', 'I'); ('T', 'B') ]
      'X' 'I';
    map_plug_test
      "Plugboard that is longer than 2 items long in the list that \
       utilizes the first item in the list to convert a letter to \
       another letter"
      [ ('A', 'B'); ('X', 'Y'); ('T', 'C') ]
      'A' 'B';
  ]

let rotor1 = { wiring = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; turnover = 'A' }

let rotor2 = { wiring = "UEJOBTPZWCNSRKDGVMLFAQIYXH"; turnover = 'A' }

let rotorex1 = { wiring = "EKMFLGDQVZNTOWYHXUSPAIBRCJ"; turnover = 'A' }

let rotorex2 = { wiring = "AJDKSIRUXBLHWTMCQGZNPYFVOE"; turnover = 'A' }

let rotorex3 = { wiring = "BDFHJLCPRTXVZNYEIWGAKMUSQO"; turnover = 'A' }

let orientation1 = { rotor = rotor1; top_letter = 'A' }

let orientation2 = { rotor = rotor2; top_letter = 'B' }

let orientationex1 = { rotor = rotorex1; top_letter = 'A' }

let orientationex2 = { rotor = rotorex2; top_letter = 'A' }

let orientationex3 = { rotor = rotorex3; top_letter = 'A' }

let config1 =
  { refl = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; rotors = []; plugboard = [] }

let config2 =
  {
    refl = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    rotors = [ orientation1 ];
    plugboard = [];
  }

let config3 =
  {
    refl = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    rotors = [ orientation2; orientation1 ];
    plugboard = [ ('A', 'Z'); ('X', 'Y') ];
  }

let config4 =
  {
    refl = "YRUHQSLDPXNGOKMIEBFZCWVJAT";
    rotors = [ orientationex1; orientationex2; orientationex3 ];
    plugboard = [];
  }

let config5 =
  {
    refl = "YRUHQSLDPXNGOKMIEBFZCWVJAT";
    rotors = [ orientationex3; orientationex2; orientationex1 ];
    plugboard = [ ('X', 'Y'); ('T', 'V') ];
  }

let cipher_char_test
    (name : string)
    (config : config)
    (c : char)
    (expected_output : char) : test =
  name >:: fun _ ->
  assert_equal expected_output (cipher_char config c)
    ~printer:(String.make 1)

let cipher_char_tests =
  [
    cipher_char_test
      "Empty rotor and plugboard with a standard reflector (alphabet \
       reflector) that does not change the input when outputting"
      config1 'A' 'A';
    cipher_char_test
      "One standard rotor (alphabet) with a standard reflector \
       (alphabet reflector) and empty plugboard, resulting in no net \
       change from input to output"
      config2 'A' 'A';
    cipher_char_test
      "Alphabet reflector that has no net change with the left rotor \
       being a A1 assignment example with top_letter B and the right \
       rotor being an alphabet rotor that creates no net change, non \
       empty plugboard"
      config3 'A' 'Z';
    cipher_char_test
      "Example given in A1 with empty plugboard, reflector B, and \
       rotor I, II, III in left to right order, all top_letters being \
       A. Input is G"
      config4 'G' 'P';
    cipher_char_test
      "Backwards rotor configuration as the example given in A1 with \
       reflector B, meaning rotor III, II, I in left to right order, \
       with all top letters being A. Input is Z with a non empty \
       plugboard."
      config5 'Z' 'Y';
  ]

let step_tests = [ (* TODO: add your tests here *) ]

let cipher_tests = [ (* TODO: add your tests here *) ]

let tests =
  "test suite for A1"
  >::: List.flatten
         [
           index_tests;
           map_rl_tests;
           map_lr_tests;
           map_refl_tests;
           map_plug_tests;
           cipher_char_tests;
           step_tests;
           cipher_tests;
         ]

let _ = run_test_tt_main tests
