(************************************************************
   Copyright (C) 2021 Cornell University.
   Created by Michael Clarkson (mrc26@cornell.edu) and CS 3110 course staff.
   You may not redistribute this assignment, distribute any derivatives,
   or use it for commercial purposes.
 ************************************************************)

(** CS 3110 Fall 2021 Assignment A1 Enigma

    @author Samuel Qian (scq5) *)

(************************************************************

  Academic Integrity Statement

  I, the person named in the author comment above, have fully reviewed
  the course academic integrity policies. I have adhered to those
  policies in solving the assignment.

  The policies do permit some limited collaboration among students
  currently enrolled in the course. If I did engage in such
  collaboration, here is the list of other students with whom I
  collaborated, and a brief summary of that collaboration:

  - none

  ************************************************************)

(** [index c] is the 0-based index of [c] in the alphabet. Requires: [c]
    is an uppercase letter in A..Z. *)
let index (c : char) : int = Char.code c - 65

(** [inverse_index] is the character output of the 0-based index of [n].
    Requires: [n] is an int between and including 0 ... 25. *)
let inverse_index (n : int) : char = Char.chr (n + 65)

(** [modulo] is a variation of the standard mod operator that allows the
    left side of the mod [x] to be negative and adjusts accordingly to
    the assignment functionality by adding [y]. Requires: [y] is an int
    > 0 and [x] is an int. *)
let modulo x y = if x >= 0 then x mod y else y + x

(** [map_r_to_l wiring top_letter input_pos] is the left-hand output
    position at which current would appear when current enters at
    right-hand input position [input_pos] to a rotor whose wiring
    specification is given by [wiring]. The orientation of the rotor is
    given by [top_letter], which is the top letter appearing to the
    operator in the rotor's present orientation. Requires: [wiring] is a
    valid wiring specification, [top_letter] is in A..Z, and [input_pos]
    is in 0..25. *)
let map_r_to_l (wiring : string) (top_letter : char) (input_pos : int) :
    int =
  modulo
    (index wiring.[modulo (input_pos + index top_letter) 26]
    - index top_letter)
    26

(** [map_l_to_r] computes the same function as [map_r_to_l], except for
    current flowing left to right. *)
let map_l_to_r (wiring : string) (top_letter : char) (input_pos : int) :
    int =
  modulo
    (String.index wiring
       (inverse_index (modulo (input_pos + index top_letter) 26))
    - index top_letter)
    26

(** [map_refl wiring input_pos] is the output position at which current
    would appear when current enters at input position [input_pos] to a
    reflector whose wiring specification is given by [wiring]. Requires:
    [wiring] is a valid reflector specification, and [input_pos] is in
    0..25. *)
let map_refl (wiring : string) (input_pos : int) : int =
  map_r_to_l wiring 'A' input_pos

(** [map_plug plugs c] is the letter to which [c] is transformed by the
    plugboard [plugs]. Requires: [plugs] is a valid plugboard, and [c]
    is in A..Z. *)
let rec map_plug (plugs : (char * char) list) (c : char) : char =
  match plugs with
  | [] -> c
  | h :: t -> if fst h = c then snd h else map_plug t c

type rotor = {
  wiring : string;  (** A valid rotor wiring specification. *)
  turnover : char;
      (** The turnover of the rotor, which must be an uppercase letter.
          This field will not be used in the assignment until you
          implement stepping in the excellent scope. *)
}
(** [rotor] represents an Enigma rotor. *)

type oriented_rotor = {
  rotor : rotor;  (** The rotor. *)
  top_letter : char;  (** The top letter showing on the rotor. *)
}
(** [oriented_rotor] represents a rotor that is installed on the spindle
    hence has a top letter. *)

type config = {
  refl : string;  (** A valid reflector wiring specification. *)
  rotors : oriented_rotor list;
      (** The rotors as they are installed on the spindle from left to
          right. There may be any number of elements in this list: 0, 1,
          2, 3, 4, 5, etc. The order of elements in list represents the
          order in which the rotors are installed on the spindle, **from
          left to right**. So, the head of the list is the leftmost
          rotor on the spindle, and the last element of the list is the
          rightmost rotor on the spindle. *)
  plugboard : (char * char) list;
      (** A valid plugboard. The order of characters in the pairs does
          not matter, and the order of pairs in the list does not
          matter. *)
}
(** [config] represents the configuration of an Enigma machine. *)

(**[r1_rotors_traversal] is a helper function which allows for the
   traversal from right to left across the set of rotors and returns an
   output of type int for a given input. Requires: [rotor_list] is a
   list containing oriented rotors], and [input_val] is an integer
   between and including 0 ... 25 *)
let rec rl_rotors_traversal
    (rotor_list : oriented_rotor list)
    (input_val : int) : int =
  match rotor_list with
  | [] -> input_val
  | h :: t ->
      rl_rotors_traversal t
        (map_r_to_l h.rotor.wiring h.top_letter input_val)

(**[lr_rotors_traversal] is a helper function which allows for the
   traversal from left to right across the set of rotors and returns an
   output of type int for a given input. Requires: [rotor_list] is a
   list containing oriented rotors], and [input_val] is an integer
   between and including 0 ... 25 *)
let rec lr_rotors_traversal
    (rotor_list : oriented_rotor list)
    (input_val : int) : int =
  match rotor_list with
  | [] -> input_val
  | h :: t ->
      lr_rotors_traversal t
        (map_l_to_r h.rotor.wiring h.top_letter input_val)

(** [cipher_char config c] is the letter to which the Enigma machine
    ciphers input [c] when it is in configuration [config]. Requires:
    [config] is a valid configuration, and [c] is in A..Z. *)
let cipher_char (config : config) (c : char) : char =
  inverse_index
    (lr_rotors_traversal config.rotors
       (map_refl config.refl
          (rl_rotors_traversal
             (List.rev config.rotors)
             (index (map_plug config.plugboard c)))))

(** [step config] is the new configuration to which the Enigma machine
    transitions when it steps beginning in configuration [config].
    Requires: [config] is a valid configuration. *)
let step (config : config) : config =
  raise (Failure "Unimplemented: Enigma.step")

(** [cipher config s] is the string to which [s] enciphers when the
    Enigma machine begins in configuration [config]. Requires: [config]
    is a valid configuration, and [s] contains only uppercase letters. *)
let rec cipher (config : config) (s : string) : string =
  raise (Failure "Unimplemented: Enigma.cipher")

let hours_worked = 11
