let hours_worked = 13
