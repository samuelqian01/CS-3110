open Wheel
open Puzzle
open Command
open Player

let consonants =
  [
    'B';
    'C';
    'D';
    'F';
    'G';
    'H';
    'J';
    'K';
    'L';
    'M';
    'N';
    'P';
    'Q';
    'R';
    'S';
    'T';
    'V';
    'W';
    'X';
    'Y';
    'Z';
  ]

let vowels = [ 'A'; 'E'; 'I'; 'O'; 'U' ]

let consonants_guessed used =
  List.filter (fun x -> List.mem x consonants) used

let no_consonants_left used =
  List.length (consonants_guessed used) = List.length consonants

let vowels_guessed used = List.filter (fun x -> List.mem x vowels) used

let all_vowels_used pzl used = vowels_guessed used = Puzzle.vowels pzl

let rec string_used used =
  match used with
  | [] -> ""
  | h :: t -> String.make 1 h ^ " " ^ string_used t

let get_rand (bound : int) =
  Random.State.int (Random.State.make_self_init ()) bound

(*returns the amount money that will be earned from a guessed letter*)
let guess_attempt pzl x chr =
  let freq = letter_freq pzl chr in
  if freq = 0 then (0, pzl) else (freq * x, guess pzl chr)

(*Parses the players input into a capital character and raises Malformed
  if it's not valid.*)

let g_parse vowel str =
  if String.length str <> 1 then raise Malformed
  else if
    vowel
    &&
    let x = int_of_char (Char.uppercase_ascii str.[0]) in
    x = 65 || x = 69 || x = 73 || x = 79 || x = 85
  then Char.uppercase_ascii str.[0]
  else if
    vowel = false
    &&
    let x = int_of_char (Char.uppercase_ascii str.[0]) in
    x > 65 && x <= 90 && x <> 69 && x <> 73 && x <> 79 && x <> 85
  then Char.uppercase_ascii str.[0]
  else raise Malformed

let guess_print wedge =
  match wedge with
  | "One Million" ->
      print_endline
        "\n\
        \ \n\
        \ Congratulations! You landed on a One Million wedge! Make \
         sure this guess is correct so that you can keep it! \n\
        \ "
  | "Wild Card" ->
      print_endline
        "\n\
        \ \n\
        \ You landed on Wild Card. If your guess is right, you'll get \
         to keep it \n\
        \ "
  | w ->
      print_endline
        ("\n \n You landed on " ^ w
       ^ " dollars. Now's your chance to guess a consonant: \n ")

let rec sub_guess player puzzle wheel wedge yield used =
  print_endline
    "\n\
    \ \n\
    \ Sorry, buddy, but that letter has already been used. Try \
     guessing again, this time with a letter that hasn't been used. If \
     you are forgetting which letters have been used, type check used \n";
  guess_helper player puzzle wheel wedge yield used

and turn_guess player puzzle wheel wedge yield used =
  guess_print wedge;
  guess_helper player puzzle wheel wedge yield used

and guess_helper player puzzle wheel wedge yield used =
  match read_line () |> g_parse false with
  | exception Malformed ->
      print_endline
        "\n\
        \ \n\
        \ Please guess a consonant. Your input was not the correct \
         type. You may guess again. \n";
      guess_helper player puzzle wheel wedge yield used
  | g_letter -> (
      if List.mem g_letter used then
        sub_guess player puzzle wheel wedge yield used
      else
        let x = g_letter |> guess_attempt puzzle yield in
        match x with
        | 0, pzl ->
            print_endline
              "\n\
              \ \n\
              \ Sorry, that letter doesn't appear in this puzzle. Your \
               turn is over \n";
            (player, pzl, g_letter :: used)
        | gains, pzl -> (
            match is_solved pzl with
            | true ->
                print_endline
                  (Puzzle.to_string pzl
                 ^ "\n \n You solved the puzzle, you win this round \n"
                  );
                (player |> earn gains |> winnings, pzl, used)
            | false -> (
                match wedge with
                | "Wild Card" ->
                    print_endline
                      (Puzzle.to_string pzl
                     ^ "\n\
                       \ \n\n\
                       \                        Congrats! You've \
                        earned a wild card. This will come in handy in \
                        the bonus round, if you manage to make it that \
                        far \n");
                    turn
                      (player |> earn gains |> give_wild_card)
                      pzl
                      (remove_wild_card wheel)
                      (g_letter :: used)
                | "One Million" ->
                    print_endline
                      (Puzzle.to_string pzl
                     ^ "\n\
                       \ \n\n\
                       \                        Congrats! You've got \
                        your hands on the Million dollar wedge. This \
                        will come in handy in the bonus round, if you \
                        manage to make it that far \n");
                    turn
                      (player |> earn gains |> give_million)
                      pzl (remove_million wheel) (g_letter :: used)
                | _ ->
                    print_endline
                      (Puzzle.to_string pzl ^ "\n \n Nice job. \n");
                    turn
                      (player |> earn gains)
                      pzl wheel (g_letter :: used))))

and turn player puzzle wheel used =
  print_endline
    "\n\
    \ \n\
    \ It's still your turn. You can either SPIN, SOLVE, BUY a vowel \
     for $250, or you can CHECK WHEEL, CHECK PUZZLE, or CHECK USED to \
     view the wheel, the puzzle, and what letters have been used so \
     far \n";
  match parse (read_line ()) with
  | Spin -> turn_spin player puzzle wheel used
  | Solve -> (
      print_endline
        "\n\
        \ \n\
        \ Type your answer to solve the puzzle. Be very careful, we \
         require exact input!\n";
      match
        String.uppercase_ascii (read_line ())
        = String.uppercase_ascii (get_answer puzzle)
      with
      | true ->
          print_endline
            (Puzzle.to_string (Puzzle.complete puzzle)
            ^ "\n \n Wow! Nice job solving that puzzle \n");
          (winnings player, complete puzzle, [])
      | _ ->
          print_endline "\n \n Tough luck. Your turn is over \n";
          (player, puzzle, used))
  | Buy -> (
      match all_vowels_used puzzle used with
      | false ->
          if round_money player >= 250 then
            buy_vowel player puzzle wheel used
          else turn player puzzle wheel used
      | true ->
          print_endline
            "\n\
            \ \n\
            \ Woah there! All the vowels in this puzzle have already \
             been found. Try guessing or solving instead \n";
          turn player puzzle wheel used)
  | CheckWheel ->
      print_endline (Wheel.to_string wheel);
      turn player puzzle wheel used
  | CheckPuzzle ->
      print_endline (Puzzle.to_string puzzle);
      turn player puzzle wheel used
  | CheckUsed ->
      print_endline (string_used used);
      turn player puzzle wheel used
  | exception Malformed -> turn player puzzle wheel used
  | exception Empty -> turn player puzzle wheel used

and turn_spin player puzzle wheel used =
  match get wheel (get_rand 24) with
  | "Bankrupt" ->
      print_endline
        "\n\
        \ \n\
        \ You landed on Bankrupt. All the money you've earned this \
         round is gone \n";
      (bankrupt player, puzzle, used)
  | "Lose a Turn" ->
      print_endline
        "\n\
        \ \n\
        \ You landed on Lose a Turn. That means that your turn has \
         ended... Obviously \n";
      (player, puzzle, used)
  | wedge -> (
      match no_consonants_left used with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ There are no consonants left to guess. You can just go \
             ahead to the part where you solve the puzzle now, or \
             guess some vowels \n";
          turn player puzzle wheel used
      | false ->
          if wedge = "Wild Card" then
            turn_guess player puzzle wheel "Wild Card" 500 used
          else if wedge = "One Million" then
            turn_guess player puzzle wheel "One Million" 500 used
          else
            turn_guess player puzzle wheel wedge (int_of_string wedge)
              used)

and buy_vowel player puzzle wheel used =
  print_endline
    "\n \n Type the vowel you want to guess is in the puzzle \n";
  match read_line () |> g_parse true with
  | exception Malformed ->
      print_endline
        "\n\
        \ \n\
        \ Please type a vowel. That's A, E, I, O, or U. Not Y, though \n";
      buy_vowel player puzzle wheel used
  | g_letter -> (
      match List.mem g_letter used with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ That vowel has already been used, please try to guess a \
             different one \n";
          turn player puzzle wheel used
      | false -> (
          match guess puzzle g_letter with
          | exception WrongGuess _ ->
              print_endline
                "\n\
                \ \n\
                \ Sorry. That vowel is not in the puzzle. Looks like \
                 your turn is over, pal \n";
              print_endline (Puzzle.to_string puzzle);
              (player |> earn ~-250, puzzle, g_letter :: used)
          | puz -> (
              match Puzzle.is_solved puz with
              | true ->
                  print_endline
                    "\n\
                    \ \n\
                    \ Nice job solving that Puzzle, but why did you \
                     choose to spend an extra $250 to do it? \n";
                  (winnings player, complete puzzle, [])
              | false -> (
                  match all_vowels_used puzzle used with
                  | false ->
                      print_endline
                        "\n\
                        \ \n\
                        \ Congrats! You picked a vowel in the puzzle. \n";
                      print_endline (Puzzle.to_string puz);
                      turn
                        (player |> earn ~-250)
                        puz wheel (g_letter :: used)
                  | true ->
                      print_endline
                        "\n\
                        \ \n\
                        \ Congrats! You picked a vowel in the puzzle. \
                         Wow, looks like there are no more values to \
                         be found in this puzzle. It's all consonants \
                         from here on out \n";
                      turn
                        (player |> earn ~-250)
                        puz wheel (g_letter :: used)))))

let rec turn_start player puzzle wheel used =
  print_endline
    (Puzzle.to_string puzzle ^ "\n It's your turn " ^ get_name player
   ^ ". Type spin to spin the wheel\n");
  match parse (read_line ()) with
  | Spin -> turn_spin player puzzle wheel used
  | exception Malformed -> turn_start player puzzle wheel used
  | exception Empty -> turn_start player puzzle wheel used
  | _ -> turn_start player puzzle wheel used