exception Tie

type t = {
  name : string;
  round : int;
  winnings : int;
  wild : bool;
  million : bool;
}

let get_name (player : t) = player.name

let new_player name =
  { name; round = 0; winnings = 0; wild = false; million = false }

let custom_player name round winnings wild million =
  { name; round; winnings; wild; million }

(**[victor_helper] constructs a list of winners from a list of players,
   based on their winnings *)
let rec victor_helper acc winner_list playerlist =
  match playerlist with
  | [] -> List.rev winner_list
  | h :: t ->
      if h.winnings = acc then
        victor_helper h.winnings (h :: winner_list) t
      else if h.winnings > acc then victor_helper h.winnings [ h ] t
      else victor_helper acc winner_list t

let victor playerlist = victor_helper 0 [] playerlist

let earn money player = { player with round = player.round + money }

let winnings player =
  {
    player with
    winnings =
      (if player.round > 1000 then player.round + player.winnings
      else 1000 + player.winnings);
  }

let has_wild_card player = if player.wild = true then true else false

let has_million player = if player.million = true then true else false

let bankrupt player =
  {
    name = player.name;
    round = 0;
    winnings = player.winnings;
    wild = false;
    million = false;
  }

let give_wild_card player = { player with wild = true }

let give_million player = { player with million = true }

let round_money player = player.round

let total_winnings player = player.winnings

let to_string player =
  player.name ^ " has obtained $"
  ^ string_of_int player.round
  ^ " for this round and $"
  ^ string_of_int player.winnings
  ^ " in total"

let remove_round_money player = { player with round = 0 }