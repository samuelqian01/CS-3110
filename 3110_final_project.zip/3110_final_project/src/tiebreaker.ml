let guess () = read_line ()

(**Parse the guess*)
let word_guess g =
  try String.capitalize_ascii g with
  | _ -> g

let matcher guess wedge = guess = wedge

let invalid_guess mult w =
  print_endline
    "\n\
    \ \n\
    \ That was not a valid guess. Please enter either a numerical \
     guess between 500 and 900 inclusive, incremented by 50, or one \
     million for the million dollar wedge, or bankrupt or lose a turn \
     for those corresponding wedges \n\
    \ \n";
  mult w

let matcher2 guess wedge =
  match guess = wedge with
  | true ->
      print_endline
        ("The amount of points that have been accumulated so far is: "
        ^ ((wedge |> int_of_string) / 100 |> string_of_int));
      int_of_string wedge / 100
  | false ->
      print_endline
        "You have guessed incorrectly. You will start with 0 points. \
         Tough way to start the tiebreaker";
      0

let rec mult_parse () =
  let guess = read_line () in
  match String.uppercase_ascii guess with
  | "ONE MILLION" -> "ONE MILLION"
  | "WILD CARD" -> "WILD CARD"
  | "BANKRUPT" -> "BANKRUPT"
  | "LOSE A TURN" -> "LOSE A TURN"
  | "500" -> "500"
  | "550" -> "550"
  | "600" -> "600"
  | "650" -> "650"
  | "700" -> "700"
  | "750" -> "750"
  | "800" -> "800"
  | "850" -> "850"
  | "900 " -> "900"
  | _ ->
      print_endline
        "Please enter a valid wedge--values must increment by fifty \
         (Please don't include the dollar sign), bankrupt, lose a \
         turn, or one million. The values must be bounded between five \
         hundred and nine hundred";
      mult_parse ()

let rec multiplier wedge =
  print_endline
    "\n\
    \ \n\
    \ Please enter your guess for what the wheel will land on \n\
    \ \n";
  let guess = mult_parse () in
  print_endline ("You landed on " ^ wedge);
  match word_guess guess with
  | "BANKRUPT" -> (
      match matcher "BANKRUPT" wedge with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ Wow. Great guess. You just saved yourself from losing \
             the game. As a reward, you will start with 10 dollars \n\
            \ \n\
            \ ";
          10
      | false ->
          print_endline
            "\n\
            \ \n\
            \ What are you stupid or something? Now you don't get \
             anything going in to the tiebreaker \n\
            \ \n";
          print_endline
            "You have guessed incorrectly. You will start with 0 \
             points. Tough way to start the tiebreaker";
          0)
  | "LOSE A TURN" -> (
      match matcher "LOSE A TURN" wedge with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ Wow. Great guess. You just save yourself from losing a \
             turn. As a reward, you will start with 10 dollars \n\
            \ \n";
          10
      | false ->
          print_endline
            "\n\
            \ \n\
            \ What are you stupid or something? Now you don't get \
             anything going in to the tiebreaker \n\
            \ \n";
          print_endline
            "You have guessed incorrectly. You will start with 0 \
             points. Tough way to start the tiebreaker";
          0)
  | "ONE MILLION" -> (
      match matcher "ONE MILLION" wedge with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ just kidding. You will not get a million dollars that \
             easily. Instead we will give you $100 to start with \n\
            \ \n";
          100
      | false ->
          print_endline
            "\n\
            \ \n\
            \ Oof. Tough luck. We will now punish you for making such \
             a reckless guess. Now you don't get anything going in to \
             the tiebreaker \n\
            \ \n";
          print_endline
            "You will start with 0 points. Tough way to start the \
             tiebreaker";
          0)
  | "WILD CARD" -> (
      match matcher "WILD CARD" wedge with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ Well done. You correctly guessed wild card We will give \
             you 10 points to start \n\
            \ \n";
          10
      | false ->
          print_endline
            "\n\
            \ \n\
            \ Oof. Tough luck. We will now punish you for making such \
             a reckless guess. Now you don't get anything going in to \
             the tiebreaker \n\
            \ \n";
          0)
  | x ->
      if
        int_of_string x >= 500
        && int_of_string x <= 900
        && int_of_string x mod 50 = 0
      then matcher2 x wedge
      else invalid_guess multiplier wedge

let get_rand (bound : int) =
  Random.State.int (Random.State.make_self_init ()) bound

let rec mult_player_lst player_lst updated =
  match player_lst with
  | [] -> updated
  | h :: t ->
      print_endline
        ("\n \n It is your turn to guess " ^ Player.get_name h ^ "\n \n");
      mult_player_lst t
        ((h, multiplier (Wheel.get (Wheel.make_wheel 1 1) (get_rand 23)))
        :: updated)

let reset_players player_list =
  List.fold_left
    (fun init p -> Player.new_player (Player.get_name p) :: init)
    [] player_list

let used = Array.make 26 '.'

exception Malformed

let letter_val_list =
  [
    ('A', 1);
    ('B', 3);
    ('C', 3);
    ('D', 2);
    ('E', 1);
    ('F', 4);
    ('G', 2);
    ('H', 4);
    ('I', 1);
    ('J', 8);
    ('K', 5);
    ('L', 1);
    ('M', 3);
    ('N', 1);
    ('O', 1);
    ('P', 3);
    ('Q', 10);
    ('R', 1);
    ('S', 1);
    ('T', 1);
    ('U', 1);
    ('V', 4);
    ('W', 4);
    ('X', 8);
    ('Y', 4);
    ('Z', 10);
  ]

let tie_parse str =
  if String.length str <> 1 then raise Malformed
  else Char.uppercase_ascii str.[0]

let is_letter letter =
  if List.mem_assoc letter letter_val_list then letter
  else raise Malformed

let rec tie_guess () =
  let guess =
    read_line
      (print_endline "\n \n Guess a letter for the puzzle \n \n")
  in
  try is_letter (tie_parse guess) with
  | Malformed ->
      print_endline "\n \n Enter a single letter \n \n";
      tie_guess ()

(*Will help for the (p,s) :: t pattern match in play_helper. Update the
  score *)

let rec get_winner (players : (Player.t * int) list) (p, score) =
  match players with
  | [] -> p
  | (player, s) :: t ->
      if s > score then get_winner t (player, s)
      else get_winner t (p, score)

let play_helperer (player, score) guess pzl =
  let freq = Puzzle.letter_freq pzl guess in
  let letter_val = List.assoc guess letter_val_list in
  (player, score + (freq * letter_val))

let rec play_helper lst pzl =
  print_endline (Puzzle.to_string pzl);
  match Puzzle.is_solved pzl with
  | false -> (
      match lst with
      | [] -> raise (Failure "Literally how?")
      | (p, s) :: t -> (
          print_endline ("It is your turn: " ^ Player.to_string p);
          let g = tie_guess () in
          match Puzzle.guess pzl g with
          | exception Puzzle.WrongGuess _ ->
              print_endline " \n \n Your guess is incorrect \n";
              play_helper (t @ [ (p, s) ]) pzl
          | letter ->
              play_helper (t @ [ play_helperer (p, s) g pzl ]) letter))
  | true ->
      print_endline
        ("\n \n The winner of the tiebreaker round is: \n \n"
        ^ (get_winner lst (Player.new_player "\n \n Nobody Won \n \n", 0)
          |> Player.get_name)
        ^ "You will be moving on to the bonus round");
      get_winner lst (Player.new_player "\n \n Nobody Won \n \n", 0)

let play playerlist =
  print_endline
    "\n\
    \ \n\
    \ Welcome to the tiebreaker. Here are the rules: first, we will \
     have each player guess what wedge they believe they will land on. \
     The options are a money amound ranging from 500 to 900 \
     incremented by 50, Bankrupt, Lose a Turn, or One Million. If you \
     guess it correctly, you will be given a certain starting score \
     greater than zero. If you guess incorrectly, you will start with \
     a score of zero. Once you have your starting score, you will play \
     a round of wheel of fortune where you can only guess letters--no \
     buying vowels, no solving, no spinning. If the letter is in the \
     puzzle, your score will be incremented by the number of times \
     that letter appears in the puzzle multiplied by the corresponding \
     point score for the letter. The point score is based off of \
     Scrabble letter scoring so the more rare a letter is, the higher \
     the letter score. Each player will only get one guess per turn, \
     no matter whether the letter was in the puzzle or not. Once the \
     puzzle is solved, the player with the highest point score will be \
     the overall winner and they will move on to the bonus round. \
     Remember, for this round, you can guess vowels without buying, \
     although it may not be in your best interest as they are more \
     common letters.  \n\
    \ \n";
  let updated_lst = mult_player_lst playerlist [] in
  let pzl = Puzzle.random_puzzle () in
  play_helper updated_lst pzl

(** let tiebreaker player_lst = let players = mult_player_lst player_lst
    in play players*)
