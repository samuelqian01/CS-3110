let get_rand (bound : int) =
  Random.State.int (Random.State.make_self_init ()) bound

let rotate_players lst =
  match lst with
  | [] -> []
  | [ x ] -> [ x ]
  | h :: t -> t @ [ h ]

let rec round wheel puz player_lst used_char =
  let player = List.hd player_lst in
  match Puzzle.is_solved puz with
  | true ->
      print_endline
        ("\n \n Updated Player: " ^ Player.get_name player ^ "\n");
      player_lst
  | false -> (
      print_endline
        ("\n \n Next Player: "
        ^ Player.get_name (List.hd (rotate_players player_lst))
        ^ "\n");
      match
        Turn.turn_start
          (List.hd (rotate_players player_lst))
          puz wheel used_char
      with
      | person, puzzle, used -> (
          match rotate_players player_lst with
          | [] -> raise (Failure "empty")
          | _ :: t -> round wheel puzzle (person :: t) used))

let start_round player_lst rnd puzzle =
  let wheel = Wheel.make_wheel rnd (get_rand 5) in
  round wheel puzzle player_lst []