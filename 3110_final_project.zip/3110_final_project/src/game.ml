let rec print_update player_lst =
  match player_lst with
  | [] -> ()
  | [ x ] -> print_endline (Player.to_string x)
  | h :: t ->
      print_endline (Player.to_string h);
      print_update t

let rec create_player_lst num lst =
  match num with
  | 0 -> lst
  | x ->
      print_endline "Enter the player's name: ";
      let name = read_line () in
      create_player_lst (x - 1) (Player.new_player name :: lst)

let remove_round player_lst =
  List.map Player.remove_round_money player_lst

let rec num_players () =
  let num = read_line () in
  match int_of_string num with
  | exception Failure _ ->
      print_endline "Please enter a valid number of players";
      num_players ()
  | x -> (
      match x > 0 with
      | true -> x
      | false ->
          print_endline "Please enter a number greater than 0";
          num_players ())

let winner_to_string lst =
  List.fold_left
    (fun init player -> Player.get_name player ^ ", " ^ init)
    "" lst

let rec game players round =
  match round with
  | 5 -> (
      print_update players;
      print_endline
        ("The winner(s) is/are: "
        ^ winner_to_string (Player.victor players));
      match Player.victor players with
      | [] ->
          failwith
            "There are no winners. This is a very unfortunate situation"
      | [ x ] -> Bonus.play x (ref (Puzzle.random_puzzle ()))
      | _ :: _ ->
          print_endline
            "Somehow, multiple people tied for first so instead of \
             letting you both go to the bonus round, we will go to a \
             tiebreaker, where you will battle it out for the chance \
             to move onto the bonus round and get more cold hard cash";
          Bonus.play
            (Tiebreaker.play (Player.victor players))
            (ref (Puzzle.random_puzzle ()))
      (* print winner and send to bonus round*))
  | 1 ->
      print_endline "Good luck! The game has begun: ";
      game
        (Round.start_round players round (Puzzle.random_puzzle ()))
        (round + 1)
  | 2
  | 3
  | 4 ->
      print_update players;
      game
        (Round.start_round (remove_round players) round
           (Puzzle.random_puzzle ()))
        (round + 1)
  | _ -> raise (Failure "Not valid round")

let start_game () =
  print_endline
    "Welcome to Wheel of Fortune. We hope you guys have a fun time \
     playing! How many people are playing?";
  let num = num_players () in
  let players = create_player_lst num [] in
  game players 1

module Info = struct
  let history () =
    print_endline
      "Wheel of Fortune is a USA based tv game show that started \
       airing in 1975."

  let hosts () =
    print_endline
      "Wheel of Fortune's current hosts are Pat Sajak and Vanna White. \
       Other past hosts include Chuck Woolery, Susan Stafford, Rolf \
       Benirschke, and Bob Goen."

  let narrators () =
    print_endline
      "Wheel of Fortune's current narrator is Jim Thornton. Charlie \
       O'Donnell, Jack Clark, and M.G. Kelly."

  let spinoffs () =
    print_endline
      "Currently, there have been two spinoffs: Wheel 2000, which ran \
       from 1997-1998 with child contestants, and Celebrity Wheel of \
       Fortune, which began in 2021."

  let international () =
    print_endline
      "Wheel of Fortune has been adapted in many countries outside the \
       US, such as Australia, the UK, Germany, Vietnam, and many more."
end

module Rules = struct
  let rules =
    print_endline
      "Our version of Wheel of Fortune consists of 4 rounds of \
       gameplay, and then a bonus round for the winner."
end
