open Yojson.Basic.Util

type t = {
  category : string;
  sentence : string;
  answer : char list;
  board : char list;
}

exception WrongGuess of char

exception NotInList

let get_rand (bound : int) =
  Random.State.int (Random.State.make_self_init ()) bound

let rec list_index index = function
  | h :: t -> if index = 0 then h else list_index (index - 1) t
  | [] -> raise NotInList

let get_location cat =
  Yojson.Basic.from_file "data/phrases.json"
  |> member (string_of_int cat)

let phrase_finder cat phrase =
  cat |> get_location |> member "Phrases" |> to_list
  |> list_index phrase |> member "Puzzle" |> to_string

let rec make_helper str (f : char -> char) acc =
  if acc < String.length str then
    f str.[acc] :: make_helper str f (acc + 1)
  else []

let make_answer cat phrase =
  make_helper (phrase_finder cat phrase) Char.uppercase_ascii 0

let make_board cat phrase =
  make_helper
    (phrase_finder cat phrase)
    (fun x ->
      if x = ' ' then x
      else if
        let c = int_of_char (Char.uppercase_ascii x) in
        c >= 65 && c <= 90
      then '_'
      else x)
    0

let get_puzzle cat phrase =
  {
    category = cat |> get_location |> member "Category" |> to_string;
    sentence = phrase_finder cat phrase;
    answer = make_answer cat phrase;
    board = make_board cat phrase;
  }

let random_puzzle () =
  let cat = get_rand 22 in
  let phrase =
    get_rand
      (cat |> get_location |> member "Phrases" |> to_list |> List.length)
  in
  get_puzzle cat phrase

let rec answer_positions answer chr counter lst =
  match answer with
  | [] -> lst
  | h :: t ->
      if h = chr then
        answer_positions t chr (counter + 1) (counter :: lst)
      else answer_positions t chr (counter + 1) lst

let rec board_change answer board answerpos counter lst =
  match board with
  | [] -> List.rev lst
  | h :: t ->
      if List.mem counter answerpos then
        board_change answer t answerpos (counter + 1)
          (List.nth answer counter :: lst)
      else board_change answer t answerpos (counter + 1) (h :: lst)

let guess puzzle chr =
  if List.mem chr puzzle.answer then
    {
      category = puzzle.category;
      sentence = puzzle.sentence;
      answer = puzzle.answer;
      board =
        board_change puzzle.answer puzzle.board
          (answer_positions puzzle.answer chr 0 [])
          0 [];
    }
  else raise (WrongGuess chr)

let letter_freq pzl chr =
  List.length (List.filter (fun x -> x = chr) pzl.answer)

let rec string_helper = function
  | [] -> ""
  | h :: t ->
      if h = ' ' then "   " ^ string_helper t
      else if h = '\'' then "[']" ^ string_helper t
      else if h = '_' then "[ ]" ^ string_helper t
      else "[" ^ Char.escaped h ^ "]" ^ string_helper t

let to_string pzl =
  string_helper pzl.board ^ "\n" ^ "Category: " ^ pzl.category

let is_solved pzl = pzl.answer = pzl.board

let solve pzl str = str = pzl.sentence

let complete pzl =
  {
    category = pzl.category;
    sentence = pzl.sentence;
    answer = pzl.answer;
    board = pzl.answer;
  }

let get_answer pzl = pzl.sentence

let is_vowel chr =
  let c = Char.uppercase_ascii chr in
  c = 'A' || c = 'E' || c = 'I' || c = 'O' || c = 'U'

let vowels pzl = List.filter is_vowel pzl.answer