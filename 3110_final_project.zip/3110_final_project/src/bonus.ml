open Puzzle

let given_letters = [ 'R'; 'S'; 'T'; 'L'; 'E' ]

(**[make_bonus_wheel] creates the bonus round wheel based on the player
   in the bonus round*)
let make_bonus_wheel player =
  let wheel =
    [
      10000;
      12500;
      15000;
      17500;
      20000;
      22500;
      25000;
      27500;
      30000;
      32500;
      35000;
      37500;
      40000;
      42500;
      45000;
      47500;
      50000;
      52500;
      55000;
      57500;
      60000;
      62500;
      65000;
      67500;
      70000;
      72500;
      75000;
      77500;
      80000;
      82500;
      85000;
      87500;
      90000;
      92500;
      95000;
      97500;
    ]
  in
  if Player.has_million player then wheel @ [ 1000000 ]
  else wheel @ [ 100000 ]

(**[consonants_left] represent the number of constants the player has
   left to guess in the bonus round*)
let consonants_left = ref 3

(**[vowels_left] represents the number of vowels the player has left to
   guess in the bonus round*)
let vowels_left = ref 1

(**[guess] handles the player guessing a letter in the bonus round
   puzzle*)

let rec vow_guess puz =
  print_endline "\n \n Please guess a vowel \n";
  let g = read_line () in
  match
    List.mem (Char.uppercase_ascii (String.get g 0)) Turn.vowels
  with
  | true -> guess puz (Char.uppercase_ascii (String.get g 0)) 0 true
  | false -> vow_guess puz

and cons_guess puz num_left =
  match num_left with
  | 0 -> vow_guess puz
  | x -> (
      print_endline "\n \n Please guess a consonant \n";
      let g = read_line () in
      match
        List.mem (Char.uppercase_ascii (String.get g 0)) Turn.consonants
      with
      | true ->
          guess puz (Char.uppercase_ascii (String.get g 0)) x false
      | false ->
          print_endline
            "\n\
            \ \n\
            \ Your input was not the correct type. You may guess again.\n";
          cons_guess puz x)

and guess puzzle g num_left vow =
  match Puzzle.guess puzzle g with
  | exception WrongGuess _ ->
      print_endline
        "\n \n That guess was not in the puzzle. Tough Luck \n";
      cons_guess puzzle (num_left - 1)
  | p ->
      print_endline "\n \n Nice Job! The updated puzzle is now: \n";
      print_endline (Puzzle.to_string p);
      if vow = false then cons_guess p (num_left - 1) else p

let bonus_spin_helper () = String.uppercase_ascii (read_line ())

let rec bonus_spin_helper_2 wheel =
  print_endline "\n \n Type \"spin\" to spin the wheel \n";
  match bonus_spin_helper () with
  | "SPIN" ->
      let num = Turn.get_rand (List.length wheel - 1) in
      List.nth wheel num
  | _ -> bonus_spin_helper_2 wheel

let bonus_spin player =
  print_endline
    "\n\
    \ \n\
    \ Spin the wheel to determine your reward should you solve the \
     bonus puzzle correctly, if you have the million dollar wedge you \
     have a chance to land on a million, if not the most you can get \
     is $100,000 \n";
  bonus_spin_helper_2 (make_bonus_wheel player)

let init_guess puz letter =
  try Puzzle.guess puz letter with
  | WrongGuess _ -> puz

let rec update_bonus puz letters =
  match letters with
  | [] -> puz
  | h :: t -> update_bonus (init_guess puz h) t

let play player puzzle =
  print_endline
    "\n\
    \ \n\
    \ Welcome to the bonus round! We will give you a puzzle with R, S, \
     T, L, E already guessed as per game rules. You will then be given \
     3 consonant guesses and 1 vowel guess. After that, you will given \
     one chance to solve the puzzle, or two if you have a wild card. \
     If you win, you will get the bonus money. Best of Luck! \n";
  let updated_puz = ref (update_bonus !puzzle given_letters) in
  let wedge = bonus_spin player in
  print_endline (Puzzle.to_string !updated_puz);
  let final_puz = cons_guess !updated_puz 3 in
  print_endline (Puzzle.to_string final_puz);
  print_endline
    "\n\
    \ \n\
    \ Here is the new puzzle with the updated guesses. You now have \
     one chance to solve the puzzle. Or two if you have a wild card. \
     Please enter your guess now. It's all or nothin' now! \n";
  let final_guess = read_line () in
  match
    String.uppercase_ascii final_guess
    = String.uppercase_ascii (get_answer !updated_puz)
  with
  | true ->
      print_endline (Puzzle.to_string (Puzzle.complete !updated_puz));
      print_endline
        ("\n\
         \ \n\
         \ Congratulations! You have won the bonus round! You have \
          just added " ^ string_of_int wedge
       ^ " to your total winnings \n");
      print_endline
        ("\n \n Your total winnings is "
        ^ string_of_int (wedge + Player.total_winnings player)
        ^ "\n")
  | false -> (
      match Player.has_wild_card player with
      | true ->
          print_endline
            "\n\
            \ \n\
            \ Since you have a wild card and managed to hold on to it \
             to the bonus round, you have been given a second chance \
             to guess the puzzle. You better get it right this time \
             because it is your last chance! \n";
          if
            String.uppercase_ascii (read_line ())
            = String.uppercase_ascii (get_answer !updated_puz)
          then (
            print_endline
              (Puzzle.to_string (Puzzle.complete !updated_puz));
            print_endline
              ("\n\
               \ \n\
               \ Congratulations! You have won the bonus round! You \
                have just added " ^ string_of_int wedge
             ^ " to your total winnings \n");
            print_endline
              ("\n \n Your total winnings is "
              ^ string_of_int (wedge + Player.total_winnings player)
              ^ "\n"))
          else (
            print_endline
              "\n\
              \ \n\
              \ Tough luck. You lost your bonus round. You're lucky \
               we're not taking any more money away. \n";
            print_endline
              ("\n \n Your total winnings is "
              ^ string_of_int (wedge + Player.total_winnings player)
              ^ "\n"))
      | false ->
          print_endline
            "\n\
            \ \n\
            \ Tough luck. You lost your bonus round. You're lucky \
             we're not taking any more money away. \n";
          print_endline
            ("\n \n Your total winnings is "
            ^ string_of_int (wedge + Player.total_winnings player)
            ^ "\n"))
