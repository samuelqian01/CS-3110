type command =
  | Spin
  | Solve
  | Buy
  | CheckWheel
  | CheckPuzzle
  | CheckUsed

exception Empty

exception Malformed

let rec parse_helper = function
  | [] -> raise Empty
  | h :: t -> (
      match String.uppercase_ascii h with
      | "SPIN" -> Spin
      | "SOLVE" -> Solve
      | "BUY" -> Buy
      | "CHECK" -> (
          match t with
          | x :: _ -> (
              match String.uppercase_ascii x with
              | "WHEEL" -> CheckWheel
              | "PUZZLE" -> CheckPuzzle
              | "USED" -> CheckUsed
              | _ -> raise Malformed)
          | _ -> raise Malformed)
      | "" -> parse_helper t
      | _ -> raise Malformed)

let parse str = parse_helper (String.split_on_char ' ' str)