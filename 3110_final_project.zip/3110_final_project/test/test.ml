open OUnit2
open Fortune

(* open Bonus *)
open Puzzle
open Wheel
open Player
open Turn
open Command

let wheels = Yojson.Basic.from_file "data/wheels.json"

let wheel_1_0 = make_wheel 1 0

let wheel_1_1 = make_wheel 1 1

let wheel_1_2 = make_wheel 1 2

let wheel_1_3 = make_wheel 1 3

let wheel_1_4 = make_wheel 1 4

let wheel_2_0 = make_wheel 2 0

let wheel_2_1 = make_wheel 2 1

let wheel_2_2 = make_wheel 2 2

let wheel_2_3 = make_wheel 2 3

let wheel_2_4 = make_wheel 2 4

let wheel_4_0 = make_wheel 4 0

let wheel_4_1 = make_wheel 4 1

let wheel_4_2 = make_wheel 4 2

let wheel_4_3 = make_wheel 4 3

let wheel_4_4 = make_wheel 4 4

let id x = x

let to_string_test name wheel expected =
  name >:: fun _ ->
  assert_equal expected (Wheel.to_string wheel) ~printer:id

let get_test name wheel wedge expected =
  name >:: fun _ -> assert_equal expected (get wheel wedge) ~printer:id

let remove_wild_card_test name wheel expected =
  name >:: fun _ ->
  assert_equal expected
    (Wheel.to_string (remove_wild_card wheel))
    ~printer:id

let remove_million_test name wheel (expected : string) =
  name >:: fun _ ->
  assert_equal expected
    (Wheel.to_string (remove_million wheel))
    ~printer:id

let wheel_tests =
  [
    to_string_test "wheel_1_0 to_string" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$800]  [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    to_string_test "wheel_1_1 to_string" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [Wild \
       Card]  [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [One \
       Million]  [$600]  [Bankrupt]  [$850]";
    to_string_test "wheel_1_2 to_string" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [One \
       Million]  [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  \
       [$550]  [$800]  [Wild Card]  [$900]  [$600]  [Bankrupt]  \
       [$850]  [$500]  [$750]  [Lose a Turn]  [$800]";
    to_string_test "wheel_1_3 to_string" wheel_1_3
      "[One Million]  [$550]  [Bankrupt]  [$750]  [$600]  [Wild Card]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    to_string_test "wheel_1_4 to_string" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [Wild \
       Card]  [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [One Million]  [$850]";
    to_string_test "wheel_2_0 to_string" wheel_2_0
      "[Wild Card]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  \
       [$700]  [One Million]  [$700]  [$850]  [$500]  [Lose a Turn]  \
       [$750]  [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  \
       [$3500]  [$900]  [$650]  [$500]  [$800]";
    to_string_test "wheel_2_1 to_string" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [One Million]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [Wild Card]  [$850]";
    to_string_test "wheel_2_2 to_string" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [One \
       Million]  [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  \
       [$650]  [$850]  [$600]  [Wild Card]  [$500]  [$750]  [$900]  \
       [Bankrupt]  [$650]  [$550]  [$3500]  [$650]";
    to_string_test "wheel_2_3 to_string" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [One Million]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [Wild Card]  [$550]";
    to_string_test "wheel_2_4 to_string" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$750]  [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    to_string_test "wheel_4_0 to_string" wheel_4_0
      "[$5000]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [$500]  \
       [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [$700]  \
       [$600]  [Bankrupt]  [$850]";
    to_string_test "wheel_4_1 to_string" wheel_4_1
      "[$600]  [$500]  [Lose a Turn]  [$700]  [$500]  [$600]  [$500]  \
       [$750]  [$700]  [$5000]  [$650]  [$800]  [$650]  [Bankrupt]  \
       [$750]  [$700]  [$500]  [$600]  [Bankrupt]  [$850]  [$600]  \
       [$900]  [$550]  [$900]";
    to_string_test "wheel_4_2 to_string" wheel_4_2
      "[$850]  [$600]  [$700]  [$550]  [$900]  [$700]  [Bankrupt]  \
       [$850]  [$5000]  [$550]  [$800]  [$900]  [$700]  [$650]  \
       [$850]  [$900]  [$500]  [$600]  [$650]  [Lose a Turn]  [$500]  \
       [$900]  [$750]  [Bankrupt]  [$650]  [$500]";
    to_string_test "wheel_4_3 to_string" wheel_4_3
      "[$650]  [$800]  [Lose a Turn]  [$800]  [$500]  [$600]  [$500]  \
       [$650]  [$700]  [$800]  [$650]  [$800]  [$5000]  [$600]  \
       [$900]  [$650]  [Bankrupt]  [$900]  [$700]  [$500]  [$800]  \
       [$800]  [Bankrupt]  [$750]  [$650]  [$550]";
    to_string_test "wheel_4_4 to_string" wheel_4_4
      "[$750]  [$650]  [$600]  [$750]  [Lose a Turn]  [$500]  \
       [Bankrupt]  [$500]  [$650]  [$5000]  [$550]  [$500]  [$600]  \
       [$550]  [$700]  [$850]  [$550]  [$700]  [$900]  [$700]  \
       [Bankrupt]  [$650]  [$600]  [$750]  [$500]  [$900]";
    get_test "wheel_1_0 first" wheel_1_0 0 "500";
    get_test "wheel_1_0 second" wheel_1_0 1 "900";
    get_test "wheel_1_0 last" wheel_1_0 23 "850";
    get_test "wheel_1_0 Bankrupt" wheel_1_0 11 "Bankrupt";
    get_test "wheel_1_0 Lose a turn" wheel_1_0 7 "Lose a Turn";
    get_test "wheel_1_0 One Million" wheel_1_0 16 "One Million";
    get_test "wheel_1_0 Wild Card" wheel_1_0 12 "Wild Card";
    get_test "wheel_1_1 first" wheel_1_1 0 "2500";
    get_test "wheel_1_1 second" wheel_1_1 1 "600";
    get_test "wheel_1_1 last" wheel_1_1 23 "850";
    get_test "wheel_1_1 Bankrupt" wheel_1_1 16 "Bankrupt";
    get_test "wheel_1_1 Lose a turn" wheel_1_1 8 "Lose a Turn";
    get_test "wheel_1_1 One Million" wheel_1_1 20 "One Million";
    get_test "wheel_1_1 Wild Card" wheel_1_1 13 "Wild Card";
    get_test "wheel_1_2 first" wheel_1_2 0 "650";
    get_test "wheel_1_2 second" wheel_1_2 1 "Bankrupt";
    get_test "wheel_1_2 last" wheel_1_2 23 "800";
    get_test "wheel_1_2 Bankrupt" wheel_1_2 1 "Bankrupt";
    get_test "wheel_1_2 Lose a turn" wheel_1_2 22 "Lose a Turn";
    get_test "wheel_1_2 One Million" wheel_1_2 6 "One Million";
    get_test "wheel_1_2 Wild Card" wheel_1_2 15 "Wild Card";
    get_test "wheel_2_0 first" wheel_2_0 0 "Wild Card";
    get_test "wheel_2_0 second" wheel_2_0 1 "900";
    get_test "wheel_2_0 last" wheel_2_0 23 "800";
    get_test "wheel_2_0 Bankrupt" wheel_2_0 2 "Bankrupt";
    get_test "wheel_2_0 Lose a turn" wheel_2_0 11 "Lose a Turn";
    get_test "wheel_2_0 One Million" wheel_2_0 7 "One Million";
    get_test "wheel_4_0 first" wheel_4_0 0 "5000";
    get_test "wheel_4_0 second" wheel_4_0 1 "600";
    get_test "wheel_4_0 last" wheel_4_0 23 "850";
    get_test "wheel_4_0 Bankrupt" wheel_4_0 16 "Bankrupt";
    get_test "wheel_4_0 Lose a turn" wheel_4_0 8 "Lose a Turn";
    remove_wild_card_test "wheel_1_0 remove wilds" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [$500]  [$800]  \
       [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_wild_card_test "wheel_1_1 remove wilds" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [$500]  \
       [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [One \
       Million]  [$600]  [Bankrupt]  [$850]";
    remove_wild_card_test "wheel_1_2 remove wilds" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [One \
       Million]  [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  \
       [$550]  [$800]  [$500]  [$900]  [$600]  [Bankrupt]  [$850]  \
       [$500]  [$750]  [Lose a Turn]  [$800]";
    remove_wild_card_test "wheel_1_3 remove wilds" wheel_1_3
      "[One Million]  [$550]  [Bankrupt]  [$750]  [$600]  [$500]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    remove_wild_card_test "wheel_1_4 remove wilds" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [$500]  \
       [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [One Million]  [$850]";
    remove_wild_card_test "wheel_2_0 remove wilds" wheel_2_0
      "[$500]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  [$700]  \
       [One Million]  [$700]  [$850]  [$500]  [Lose a Turn]  [$750]  \
       [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  [$3500]  \
       [$900]  [$650]  [$500]  [$800]";
    remove_wild_card_test "wheel_2_1 remove wilds" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [One Million]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [$500]  [$850]";
    remove_wild_card_test "wheel_2_2 remove wilds" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [One \
       Million]  [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  \
       [$650]  [$850]  [$600]  [$500]  [$500]  [$750]  [$900]  \
       [Bankrupt]  [$650]  [$550]  [$3500]  [$650]";
    remove_wild_card_test "wheel_2_3 remove wilds" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [One Million]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [$500]  [$550]";
    remove_wild_card_test "wheel_2_4 remove wilds" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [$500]  [$750]  \
       [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_million_test "wheel_1_0 remove million" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$800]  [$500]  [$700]  [Bankrupt]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_million_test "wheel_1_1 remove million" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [Wild \
       Card]  [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  \
       [Bankrupt]  [$600]  [Bankrupt]  [$850]";
    remove_million_test "wheel_1_2 remove million" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [Bankrupt]  \
       [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  [$550]  \
       [$800]  [Wild Card]  [$900]  [$600]  [Bankrupt]  [$850]  \
       [$500]  [$750]  [Lose a Turn]  [$800]";
    remove_million_test "wheel_1_3 remove million" wheel_1_3
      "[Bankrupt]  [$550]  [Bankrupt]  [$750]  [$600]  [Wild Card]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    remove_million_test "wheel_1_4 remove million" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [Wild \
       Card]  [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [Bankrupt]  [$850]";
    remove_million_test "wheel_2_0 remove million" wheel_2_0
      "[Wild Card]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  \
       [$700]  [Bankrupt]  [$700]  [$850]  [$500]  [Lose a Turn]  \
       [$750]  [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  \
       [$3500]  [$900]  [$650]  [$500]  [$800]";
    remove_million_test "wheel_2_1 remove million" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [Bankrupt]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [Wild Card]  [$850]";
    remove_million_test "wheel_2_2 remove million" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [Bankrupt]  \
       [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  [$650]  [$850]  \
       [$600]  [Wild Card]  [$500]  [$750]  [$900]  [Bankrupt]  \
       [$650]  [$550]  [$3500]  [$650]";
    remove_million_test "wheel_2_3 remove million" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [Bankrupt]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [Wild Card]  [$550]";
    remove_million_test "wheel_2_4 remove million" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$750]  [$500]  [$700]  [Bankrupt]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
  ]

let bob = custom_player "Bob" 0 0 false false

let sally = custom_player "Sally" 0 0 false false

let clarkson = custom_player "Clarkson" 0 0 false false

let gene = custom_player "Gene" 0 100 false false

let bill = custom_player "Bill" 0 50 false false

let carl = custom_player "Carl" 30 40 false false

let will = custom_player "Will" 0 100 false false

let sam = custom_player "Sam" 0 100 true true

let mike = custom_player "Mike" 10 150 true false

let minki = custom_player "Minki" 10000 150 false true

let get_name_test name player expected =
  name >:: fun _ -> assert_equal expected (get_name player) ~printer:id

let victor_test name players expected =
  name >:: fun _ -> assert_equal expected (victor players)

let has_wild_card_test name player expected =
  name >:: fun _ ->
  assert_equal expected (has_wild_card player) ~printer:string_of_bool

let has_million_test name player expected =
  name >:: fun _ ->
  assert_equal expected (has_million player) ~printer:string_of_bool

let round_money_test name player expected =
  name >:: fun _ ->
  assert_equal expected (round_money player) ~printer:string_of_int

let total_winnings_test name player expected =
  name >:: fun _ ->
  assert_equal expected (total_winnings player) ~printer:string_of_int

let player_tests =
  [
    get_name_test "Bob getting" bob "Bob";
    get_name_test "Sally getting" sally "Sally";
    get_name_test "clarkson getting" clarkson "Clarkson";
    get_name_test "gene getting" gene "Gene";
    victor_test "gene winning against nonzeros"
      [ gene; clarkson; carl ]
      [ gene ];
    victor_test "gene winning in middle against zeros"
      [ clarkson; gene; bob ] [ gene ];
    victor_test "gene winning in middle against nonzeros"
      [ clarkson; gene; carl ]
      [ gene ];
    victor_test "gene winning at end against zeros"
      [ clarkson; bob; gene ] [ gene ];
    victor_test "tie without money "
      [ bob; sally; clarkson ]
      [ bob; sally; clarkson ];
    victor_test "gene winning at end against nonzeros"
      [ clarkson; bob; gene ] [ gene ];
    victor_test "tie with money" [ sam; will; carl ] [ sam; will ];
    round_money_test "zero adding positive" (earn 100 will) 100;
    round_money_test " zero adding negative" (earn ~-100 will) ~-100;
    round_money_test "positive adding positive" (earn 150 mike) 160;
    round_money_test "positive adding negative" (earn ~-150 mike) ~-140;
    round_money_test "bankrupting with positive money" (bankrupt mike) 0;
    round_money_test "bankrupting with no round money" (bankrupt will) 0;
    total_winnings_test "wills winnings" (winnings will) 1100;
    total_winnings_test "mikes winnings" (winnings mike) 1150;
    total_winnings_test "clarkson winnings" (winnings clarkson) 1000;
    total_winnings_test "minki winnings" (winnings minki) 10150;
    has_wild_card_test "minki wild card" minki false;
    has_wild_card_test "giving minki a wild card" (give_wild_card minki)
      true;
    has_wild_card_test "mike wild card" mike true;
    has_wild_card_test "giving minke a wild card" (give_wild_card mike)
      true;
    has_wild_card_test "sam wild card" sam true;
    has_wild_card_test "giving sam a wild card" (give_wild_card sam)
      true;
    has_wild_card_test "will wild card" will false;
    has_wild_card_test "giving minki a wild card" (give_wild_card minki)
      true;
    has_million_test "minki million" minki true;
    has_million_test "minki given million" (give_million minki) true;
    has_million_test "mike million" mike false;
    has_million_test "mike given million" (give_million mike) true;
    has_million_test "sam million" sam true;
    has_million_test "sam given million" (give_million sam) true;
    has_million_test "will million" will false;
    has_million_test "will given million" (give_million will) true;
  ]

let guess_test name puzzle chr expected =
  name >:: fun _ -> assert_equal expected (guess puzzle chr)

let to_string_puzzle_test name puzzle expected =
  name >:: fun _ ->
  assert_equal expected (Puzzle.to_string puzzle) ~printer:id

let solve_test name puzzle str expected =
  name >:: fun _ ->
  assert_equal expected (solve puzzle str) ~printer:string_of_bool

let is_solved_test name pzl expected =
  name >:: fun _ -> assert_equal expected (is_solved pzl)

let complete_test name pzl expected =
  name >:: fun _ -> assert_equal expected (complete pzl)

let wrong_guess_test name pzl letter =
  name >:: fun _ ->
  let f () = guess pzl letter in
  assert_raises (WrongGuess letter) f

let letter_freq_test name pzl chr expected =
  name >:: fun _ ->
  assert_equal expected (letter_freq pzl chr) ~printer:string_of_int

let ( +> ) = guess

let burger = get_puzzle 0 0

let apples = get_puzzle 0 1

let angora = get_puzzle 1 0

let jeans = get_puzzle 1 1

let roast = get_puzzle 0 26

let egg = get_puzzle 0 10

let devil = get_puzzle 0 9

let solved_roast = roast +> 'P' +> 'O' +> 'T' +> 'R' +> 'S' +> 'A'

let crowd = get_puzzle 14 27

let yoyo = get_puzzle 6 26

let breeze = get_puzzle 15 34

let fried_egg = get_puzzle 0 12

let puzzle_tests =
  [
    to_string_puzzle_test
      "The Hamburger and Fries starts as a series of empty slots" burger
      "[ ][ ][ ][ ][ ][ ][ ][ ][ ]   [ ][ ][ ]   [ ][ ][ ][ ][ ]\n\
       Category: Food & Drink";
    solve_test
      "The solution to Hamburger and Fries is Hamburger and Fries"
      burger "Hamburger and Fries" true;
    solve_test
      "The solution to Hamburger and Fries is Burger and Fries (should \
       return false)"
      burger "Burger and Fries" false;
    to_string_puzzle_test
      "Pot Roast after guessing P is P and then several empty slots"
      (guess roast 'P')
      "[P][ ][ ]   [ ][ ][ ][ ][ ]\nCategory: Food & Drink";
    to_string_puzzle_test
      "Pot Roast after guessing T is several empty slots with T at the \
       end of each word"
      (guess roast 'T')
      "[ ][ ][T]   [ ][ ][ ][ ][T]\nCategory: Food & Drink";
    to_string_puzzle_test
      "Pot Roast after guessing every letter is Pot Roast" solved_roast
      "[P][O][T]   [R][O][A][S][T]\nCategory: Food & Drink";
    to_string_puzzle_test "The Hamburger and Fries after guessing E "
      (guess burger 'E')
      "[ ][ ][ ][ ][ ][ ][ ][E][ ]   [ ][ ][ ]   [ ][ ][ ][E][ ]\n\
       Category: Food & Drink";
    to_string_puzzle_test
      "The Hamburger and Fries after guessing E and then H "
      (burger +> 'E' +> 'H')
      "[H][ ][ ][ ][ ][ ][ ][E][ ]   [ ][ ][ ]   [ ][ ][ ][E][ ]\n\
       Category: Food & Drink";
    wrong_guess_test
      "The Hamburger and Fries after guessing E and then W "
      (burger +> 'E') 'W';
    to_string_puzzle_test "Deviled Eggs representation" devil
      "[ ][ ][ ][ ][ ][ ][ ]   [ ][ ][ ][ ]\nCategory: Food & Drink";
    wrong_guess_test "Deviled Eggs after guessing Z " devil 'Z';
    to_string_puzzle_test
      "The In-Crowd is a series of empty slots with a hyphen in the \
       middle"
      crowd "[ ][ ][ ]   [ ][ ][-][ ][ ][ ][ ][ ]\nCategory: People";
    to_string_puzzle_test
      "Yo-yo tricks is just a hyphen surrounded by blank slots" yoyo
      "[ ][ ][-][ ][ ]   [ ][ ][ ][ ][ ][ ]\nCategory: Fun & Games";
    to_string_puzzle_test
      "It's a breeze is a single apostrophe and nothing else" breeze
      "[ ][ ]['][ ]   [ ]   [ ][ ][ ][ ][ ][ ]\nCategory: Phrase";
    is_solved_test "Pot roast after all letters are guessed is solved"
      solved_roast true;
    is_solved_test "Pot roast is not solved before any guesses are made"
      roast false;
    is_solved_test "Pot roast with one guess is not solved"
      (roast +> 'A') false;
    letter_freq_test "apples testing a(letters across multiple words"
      apples 'A' 2;
    letter_freq_test "apples testing z" apples 'Z' 0;
    letter_freq_test "angora testing e(letters only in 1 word)" angora
      'E' 2;
    letter_freq_test
      "fried egg testing s(letters only in upper+lowercase)" fried_egg
      'S' 4;
    to_string_puzzle_test "Egg-and-Cheese Sandwich representation" egg
      "[ ][ ][ ][-][ ][ ][ ][-][ ][ ][ ][ ][ ][ ]   [ ][ ][ ][ ][ ][ \
       ][ ][ ]\n\
       Category: Food & Drink";
    to_string_puzzle_test "Egg-and-Cheese Sandwich after guessing E"
      (egg +> 'E')
      "[E][ ][ ][-][ ][ ][ ][-][ ][ ][E][E][ ][E]   [ ][ ][ ][ ][ ][ \
       ][ ][ ]\n\
       Category: Food & Drink";
    to_string_puzzle_test "Deviled Eggs representation" devil
      "[ ][ ][ ][ ][ ][ ][ ]   [ ][ ][ ][ ]\nCategory: Food & Drink";
    wrong_guess_test "Deviled Eggs after guessing Z " devil 'Z';
  ]

let guess_attempt_test name pzl x chr expected =
  name >:: fun _ -> assert_equal expected (guess_attempt pzl x chr)

let g_parse_test name vowel str expected =
  name >:: fun _ -> assert_equal expected (g_parse vowel str)

let g_parse_exception_test name vowel str =
  name >:: fun _ ->
  let f () = g_parse vowel str in
  assert_raises Malformed f

let turn_guess_test name player puzzle wheel wedge yield used expected =
  name >:: fun _ ->
  assert_equal expected
    (turn_guess player puzzle wheel wedge yield used)

(* let turn_guess_exception = *)

let turn_tests =
  [
    guess_attempt_test
      "Testing money returned with multiple frequency of letter a in \
       apples with cinammon (duplicates) when on wheel of value 750"
      apples 750 'A'
      (1500, guess apples 'A');
    guess_attempt_test
      "Testing money returned after spinning for 500 and guessing H in \
       hamburger and fries"
      burger 500 'H'
      (500, guess burger 'H');
    guess_attempt_test
      "Testing money returned after spinning for 500 and guessing Z in \
       hamburger and fries"
      burger 500 'Z' (0, burger);
    guess_attempt_test
      "Testing money returned after spinning for 500 and guessing R in \
       hamburger and fries"
      burger 500 'R'
      (1500, guess burger 'R');
    g_parse_exception_test "string longer than length 1, g_parse" false
      "hello";
    g_parse_exception_test "string len = 1, vowel = true, not a vowel"
      true "g";
    g_parse_exception_test "string len = 1, vowel = false, is a vowel"
      false "i";
    g_parse_test "string len 1, vowel = true, a" true "a" 'A';
    g_parse_test "string len 1, vowel false, not vowel" false "b" 'B';
  ]

let boston = get_puzzle 0 3

let showers = get_puzzle 18 0

let bonus_tests = []

let suite =
  "test suite for Wheel of Fortune"
  >::: List.flatten
         [ wheel_tests; player_tests; puzzle_tests; turn_tests ]

let _ = run_test_tt_main suite