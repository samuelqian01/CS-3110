open OUnit2
open Game
open Adventure
open Command
open State

(********************************************************************
   Here are some helper functions for your testing of set-like lists.
 ********************************************************************)

(** [cmp_set_like_lists lst1 lst2] compares two lists to see whether
    they are equivalent set-like lists. That means checking two things.
    First, they must both be {i set-like}, meaning that they do not
    contain any duplicates. Second, they must contain the same elements,
    though not necessarily in the same order. *)
let cmp_set_like_lists lst1 lst2 =
  let uniq1 = List.sort_uniq compare lst1 in
  let uniq2 = List.sort_uniq compare lst2 in
  List.length lst1 = List.length uniq1
  && List.length lst2 = List.length uniq2
  && uniq1 = uniq2

(** [pp_string s] pretty-prints string [s]. *)
let pp_string s = "\"" ^ s ^ "\""

(** [pp_list pp_elt lst] pretty-prints list [lst], using [pp_elt] to
    pretty-print each element of [lst]. *)
let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [ h ] -> acc ^ pp_elt h
      | h1 :: (h2 :: t as t') ->
          if n = 100 then acc ^ "..." (* stop printing long list *)
          else loop (n + 1) (acc ^ pp_elt h1 ^ "; ") t'
    in
    loop 0 "" lst
  in
  "[" ^ pp_elts lst ^ "]"

(* These tests demonstrate how to use [cmp_set_like_lists] and [pp_list]
   to get helpful output from OUnit. *)
let cmp_demo =
  [
    ( "order is irrelevant" >:: fun _ ->
      assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
        [ "foo"; "bar" ] [ "bar"; "foo" ] );
    (* Uncomment this test to see what happens when a test case fails.
       "duplicates not allowed" >:: (fun _ -> assert_equal
       ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string) ["foo";
       "foo"] ["foo"]); *)
  ]

(********************************************************************
   End helper functions.
 ********************************************************************)

(* You are welcome to add strings containing JSON here, and use them as
   the basis for unit tests. You can also use the JSON files in the data
   directory as tests. And you can add JSON files in this directory and
   use them, too. *)

(* You should not be testing any helper functions here. Test only the
   functions exposed in the [.mli] files. Do not expose your helper
   functions. See the handout for an explanation. *)

(* TODO: add unit tests for modules below. You are free to reorganize
   the definitions below. Just keep it clear which tests are for which
   modules. *)
let j = Yojson.Basic.from_file "data/ho_plaza.json"

let j1 = Yojson.Basic.from_file "data/lonely_room.json"

let start_room_test (name : string) adv expected_output =
  name >:: fun _ -> assert_equal expected_output (start_room adv)

let room_ids_test (name : string) adv expected_output =
  name >:: fun _ ->
  assert (cmp_set_like_lists expected_output (room_ids adv))

let description_test (name : string) adv room expected_output =
  name >:: fun _ -> assert_equal expected_output (description adv room)

let exits_test (name : string) adv room expected_output =
  name >:: fun _ ->
  assert_equal true
    (cmp_set_like_lists expected_output (exits adv room))

let next_room_test (name : string) adv room ex expected_output =
  name >:: fun _ -> assert_equal expected_output (next_room adv room ex)

let next_rooms_test (name : string) adv room expected_output =
  name >:: fun _ ->
  assert_equal true
    (cmp_set_like_lists expected_output (next_rooms adv room))

let adventure_tests =
  [
    start_room_test "Testing Ho Plaza JSON start room" (from_json j)
      "ho plaza";
    room_ids_test
      "Checking to make sure the list of room's IDs show up for \
       ho_plaza"
      (from_json j)
      [ "ho plaza"; "health"; "tower"; "nirvana" ];
    room_ids_test
      "Checking to make sure the list of room's IDs show up for \
       lonely_room"
      (from_json j1) [ "the room" ];
    description_test
      "Checking to make sure the description is correct for ho_plaza \
       for room health"
      (from_json j) "health"
      "You are at the entrance to Cornell Health. A sign advertises \
       free flu shots. You briefly wonder how long it would take to \
       get an appointment. Ho Plaza is to the northeast.";
    description_test
      "Checking to make sure the description is correct for \
       lonely_room for room the room"
      (from_json j1) "the room" "A very lonely room.";
    exits_test
      "Checking to make sure the exit_name list is correct for Ho Plaza"
      (from_json j) "tower"
      [ "down"; "back"; "Ho Plaza"; "higher" ];
    exits_test
      "Checking to make sure the exit_name list is correct for lonely \
       room"
      (from_json j1) "the room" [];
    next_room_test
      "Checking to make sure the next room from the given exit and \
       room is correct for Ho Plaza"
      (from_json j) "ho plaza" "chimes" "tower";
    next_rooms_test
      "Checking to make sure the next rooms for a given room are \
       correct for Ho Plaza"
      (from_json j) "tower"
      [ "ho plaza"; "nirvana" ];
    next_rooms_test
      "Checking to make sure the next rooms for a given room are \
       correct for lonely_room"
      (from_json j1) "the room" [];
  ]

let parse_test (name : string) str expected_output =
  name >:: fun _ -> assert_equal expected_output (parse str)

let parse_test_exception (name : string) str exception_name =
  name >:: fun _ -> assert_raises exception_name (fun () -> parse str)

let command_tests =
  [
    parse_test "Testing go for a valid input" "go clock tower"
      (Go [ "clock"; "tower" ]);
    parse_test "Testing quit for a valid input" "quit" Quit;
    parse_test_exception "Raising exception Empty for an input" "" Empty;
    parse_test_exception "Raising exception Malformed for an input"
      "quit hello" Malformed;
  ]

let go_test (name : string) ex adv st expected_output =
  name >:: fun _ -> assert_equal expected_output (go ex adv st)

let go_test_legal
    (name : string)
    ex
    adv
    st
    expected_state
    expected_visited =
  name >:: fun _ ->
  assert_equal
    (expected_state = Adventure.next_room adv (current_room_id st) ex)
    (expected_visited
    = List.sort_uniq compare
        (Adventure.next_room adv (current_room_id st) ex :: visited st)
    )

let state_tests =
  [
    go_test "Testing for an Illegal series of inputs" "down"
      (from_json j)
      (init_state (from_json j))
      Illegal;
    go_test_legal "Testing for an legal series of inputs" "southwest"
      (from_json j)
      (init_state (from_json j))
      "health"
      (List.sort_uniq compare [ "ho plaza"; "health" ]);
  ]

let suite =
  "test suite for A2"
  >::: List.flatten [ adventure_tests; command_tests; state_tests ]

let _ = run_test_tt_main suite
