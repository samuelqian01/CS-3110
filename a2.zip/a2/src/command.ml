(* Note: You may introduce new code anywhere in this file. *)

type object_phrase = string list

type command =
  | Go of object_phrase
  | Quit

exception Empty

exception Malformed

let stringlist str =
  List.filter (fun x -> x <> " ") (String.split_on_char ' ' str)

let malformed str =
  if
    List.nth (stringlist str) 0 <> "go"
    && List.nth (stringlist str) 0 <> "quit"
  then true
  else if
    List.length (stringlist str) = 1
    && List.nth (stringlist str) 0 = "go"
  then true
  else if
    List.length (stringlist str) <> 1
    && List.nth (stringlist str) 0 = "quit"
  then true
  else false

let decide str =
  if List.nth (stringlist str) 0 = "quit" then Quit
  else Go (List.filter (fun x -> x <> "go") (stringlist str))

let parse str =
  if str = "" then raise Empty
  else if malformed str then raise Malformed
  else decide str
