(* Note: You may introduce new code anywhere in this file. *)
open Yojson.Basic.Util

type room_id = string

type exit_name = string

exception UnknownRoom of room_id

exception UnknownExit of exit_name

(* TODO: replace [unit] with a type of your own design. *)

type exit = {
  name : exit_name;
  room_id : room_id;
}

type room = {
  id : room_id;
  description : string;
  exits : exit list;
}

type t = {
  rooms : room list;
  start_room : room_id;
}

let exit_of_json json =
  {
    name = json |> member "name" |> to_string;
    room_id = json |> member "room id" |> to_string;
  }

let room_of_json json =
  {
    id = json |> member "id" |> to_string;
    description = json |> member "description" |> to_string;
    exits = json |> member "exits" |> to_list |> List.map exit_of_json;
  }

let from_json json =
  {
    rooms = json |> member "rooms" |> to_list |> List.map room_of_json;
    start_room =
      json |> to_assoc |> List.assoc "start room" |> to_string;
  }

let start_room adv = adv.start_room

let room_id_acc (rooms : room list) = List.map (fun x -> x.id) rooms

let list_of_exits (rooms : room list) =
  List.flatten (List.map (fun x -> x.exits) rooms)

let room_of_rooms (rooms : room list) target_room =
  List.find (fun x -> x.id = target_room) rooms

let exits_of_room (room : room) = List.map (fun x -> x.name) room.exits

let room_ids adv =
  if List.length adv.rooms = 0 then [ start_room adv ]
  else
    List.sort_uniq compare (start_room adv :: (adv.rooms |> room_id_acc))

let description adv room =
  if List.mem room (room_ids adv) = false then raise (UnknownRoom room)
  else
    (List.nth (List.filter (fun x -> x.id = room) adv.rooms) 0)
      .description

let exits adv room =
  if List.mem room (room_ids adv) = false then raise (UnknownRoom room)
  else
    room_of_rooms adv.rooms room
    |> exits_of_room |> List.sort_uniq compare

let next_room adv room ex =
  if List.mem ex (exits adv room) = false then raise (UnknownExit ex)
  else
    (List.nth
       (List.filter (fun x -> x.name = ex) (adv.rooms |> list_of_exits))
       0)
      .room_id

let next_rooms adv room =
  if List.mem room (room_ids adv) = false then raise (UnknownRoom room)
  else
    List.filter (fun x -> x.id = room) adv.rooms
    |> list_of_exits
    |> List.map (fun x -> x.room_id)
    |> List.sort_uniq compare
