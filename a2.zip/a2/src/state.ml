(* Note: You may introduce new code anywhere in this file. *)

(* TODO: replace [unit] with a type of your own design. *)
type t = {
  current_state : Adventure.room_id;
  visited : Adventure.room_id list;
}

let init_state adv =
  {
    current_state = Adventure.start_room adv;
    visited = [ Adventure.start_room adv ];
  }

let current_room_id st = st.current_state

let visited st = List.sort_uniq compare st.visited

type result =
  | Legal of t
  | Illegal

let check_exits ex adv st =
  try Adventure.next_room adv (current_room_id st) ex with
  | Adventure.UnknownExit ex -> "illegal"

let go ex adv st =
  if check_exits ex adv st = "illegal" then Illegal
  else
    Legal
      {
        current_state = Adventure.next_room adv (current_room_id st) ex;
        visited =
          List.sort_uniq compare
            (Adventure.next_room adv (current_room_id st) ex
            :: visited st);
      }
