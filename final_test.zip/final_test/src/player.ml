type t

let start = raise (Failure "unimplemented")

let winner = raise (Failure "unimplemented")
