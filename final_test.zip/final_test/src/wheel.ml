open Yojson.Basic.Util

type wedge = string

exception MissingWedge of wedge

type t = wedge list

let wedge_from_json j = j |> member "wedge" |> to_string

let wheel_from_json json round index =
  json
  |> member (string_of_int round)
  |> member (string_of_int index)
  |> to_list
  |> List.map wedge_from_json

let from_json json round index =
  try wheel_from_json json round index with
  | Type_error (s, _) -> failwith ("Parsing error: " ^ s)

let make_wheel round index =
  from_json (Yojson.Basic.from_file "data/wheels.json") round index

let is_special_wedge h =
  h = "Bankrupt" || h = "Lose a Turn" || h = "Wild Card"
  || h = "One Million"

let rec to_string wheel : wedge =
  match wheel with
  | [] -> ""
  | [ h ] ->
      if is_special_wedge h then "[" ^ h ^ "]" else "[$" ^ h ^ "]"
  | h :: t ->
      if is_special_wedge h then "[" ^ h ^ "]" ^ "  " ^ to_string t
      else "[$" ^ h ^ "]" ^ "  " ^ to_string t

let get (wheel : t) index : wedge = List.nth wheel index

let rec remove_helper (wheel : t) org sub : t =
  match wheel with
  | [] -> raise (MissingWedge org)
  | h :: t -> if h = org then sub :: t else h :: remove_helper t org sub

let remove_wild_card (wheel : t) : t =
  remove_helper wheel "Wild Card" "500"

let remove_million (wheel : t) : t =
  remove_helper wheel "One Million" "Bankrupt"