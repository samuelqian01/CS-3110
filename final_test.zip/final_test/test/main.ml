open OUnit2
open Fortune
open Wheel

let wheels = Yojson.Basic.from_file "data/wheels.json"

let wheel_1_0 = make_wheel 1 0

let wheel_1_1 = make_wheel 1 1

let wheel_1_2 = make_wheel 1 2

let wheel_1_3 = make_wheel 1 3

let wheel_1_4 = make_wheel 1 4

let wheel_2_0 = make_wheel 2 0

let wheel_2_1 = make_wheel 2 1

let wheel_2_2 = make_wheel 2 2

let wheel_2_3 = make_wheel 2 3

let wheel_2_4 = make_wheel 2 4

let wheel_4_0 = make_wheel 4 0

let wheel_4_1 = make_wheel 4 1

let wheel_4_2 = make_wheel 4 2

let wheel_4_3 = make_wheel 4 3

let wheel_4_4 = make_wheel 4 4

let id x = x

let to_string_test name wheel expected =
  name >:: fun _ -> assert_equal expected (to_string wheel) ~printer:id

let get_test name wheel wedge expected =
  name >:: fun _ -> assert_equal expected (get wheel wedge) ~printer:id

let remove_wild_card_test name wheel expected =
  name >:: fun _ ->
  assert_equal expected (to_string (remove_wild_card wheel)) ~printer:id

let remove_million_test name wheel (expected : string) =
  name >:: fun _ ->
  assert_equal expected (to_string (remove_million wheel)) ~printer:id

let wheel_tests =
  [
    to_string_test "wheel_1_0 to_string" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$800]  [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    to_string_test "wheel_1_1 to_string" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [Wild \
       Card]  [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [One \
       Million]  [$600]  [Bankrupt]  [$850]";
    to_string_test "wheel_1_2 to_string" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [One \
       Million]  [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  \
       [$550]  [$800]  [Wild Card]  [$900]  [$600]  [Bankrupt]  \
       [$850]  [$500]  [$750]  [Lose a Turn]  [$800]";
    to_string_test "wheel_1_3 to_string" wheel_1_3
      "[One Million]  [$550]  [Bankrupt]  [$750]  [$600]  [Wild Card]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    to_string_test "wheel_1_4 to_string" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [Wild \
       Card]  [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [One Million]  [$850]";
    to_string_test "wheel_2_0 to_string" wheel_2_0
      "[Wild Card]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  \
       [$700]  [One Million]  [$700]  [$850]  [$500]  [Lose a Turn]  \
       [$750]  [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  \
       [$3500]  [$900]  [$650]  [$500]  [$800]";
    to_string_test "wheel_2_1 to_string" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [One Million]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [Wild Card]  [$850]";
    to_string_test "wheel_2_2 to_string" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [One \
       Million]  [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  \
       [$650]  [$850]  [$600]  [Wild Card]  [$500]  [$750]  [$900]  \
       [Bankrupt]  [$650]  [$550]  [$3500]  [$650]";
    to_string_test "wheel_2_3 to_string" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [One Million]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [Wild Card]  [$550]";
    to_string_test "wheel_2_4 to_string" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$750]  [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    to_string_test "wheel_4_0 to_string" wheel_4_0
      "[$5000]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [$500]  \
       [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [$700]  \
       [$600]  [Bankrupt]  [$850]";
    to_string_test "wheel_4_1 to_string" wheel_4_1
      "[$600]  [$500]  [Lose a Turn]  [$700]  [$500]  [$600]  [$500]  \
       [$750]  [$700]  [$5000]  [$650]  [$800]  [$650]  [Bankrupt]  \
       [$750]  [$700]  [$500]  [$600]  [Bankrupt]  [$850]  [$600]  \
       [$900]  [$550]  [$900]";
    to_string_test "wheel_4_2 to_string" wheel_4_2
      "[$850]  [$600]  [$700]  [$550]  [$900]  [$700]  [Bankrupt]  \
       [$850]  [$5000]  [$550]  [$800]  [$900]  [$700]  [$650]  \
       [$850]  [$900]  [$500]  [$600]  [$650]  [Lose a Turn]  [$500]  \
       [$900]  [$750]  [Bankrupt]  [$650]  [$500]";
    to_string_test "wheel_4_3 to_string" wheel_4_3
      "[$650]  [$800]  [Lose a Turn]  [$800]  [$500]  [$600]  [$500]  \
       [$650]  [$700]  [$800]  [$650]  [$800]  [$5000]  [$600]  \
       [$900]  [$650]  [Bankrupt]  [$900]  [$700]  [$500]  [$800]  \
       [$800]  [Bankrupt]  [$750]  [$650]  [$550]";
    to_string_test "wheel_4_4 to_string" wheel_4_4
      "[$750]  [$650]  [$600]  [$750]  [Lose a Turn]  [$500]  \
       [Bankrupt]  [$500]  [$650]  [$5000]  [$550]  [$500]  [$600]  \
       [$550]  [$700]  [$850]  [$550]  [$700]  [$900]  [$700]  \
       [Bankrupt]  [$650]  [$600]  [$750]  [$500]  [$900]";
    get_test "wheel_1_0 first" wheel_1_0 0 "500";
    get_test "wheel_1_0 second" wheel_1_0 1 "900";
    get_test "wheel_1_0 last" wheel_1_0 23 "850";
    get_test "wheel_1_0 Bankrupt" wheel_1_0 11 "Bankrupt";
    get_test "wheel_1_0 Lose a turn" wheel_1_0 7 "Lose a Turn";
    get_test "wheel_1_0 One Million" wheel_1_0 16 "One Million";
    get_test "wheel_1_0 Wild Card" wheel_1_0 12 "Wild Card";
    get_test "wheel_1_1 first" wheel_1_1 0 "2500";
    get_test "wheel_1_1 second" wheel_1_1 1 "600";
    get_test "wheel_1_1 last" wheel_1_1 23 "850";
    get_test "wheel_1_1 Bankrupt" wheel_1_1 16 "Bankrupt";
    get_test "wheel_1_1 Lose a turn" wheel_1_1 8 "Lose a Turn";
    get_test "wheel_1_1 One Million" wheel_1_1 20 "One Million";
    get_test "wheel_1_1 Wild Card" wheel_1_1 13 "Wild Card";
    get_test "wheel_1_2 first" wheel_1_2 0 "650";
    get_test "wheel_1_2 second" wheel_1_2 1 "Bankrupt";
    get_test "wheel_1_2 last" wheel_1_2 23 "800";
    get_test "wheel_1_2 Bankrupt" wheel_1_2 1 "Bankrupt";
    get_test "wheel_1_2 Lose a turn" wheel_1_2 22 "Lose a Turn";
    get_test "wheel_1_2 One Million" wheel_1_2 6 "One Million";
    get_test "wheel_1_2 Wild Card" wheel_1_2 15 "Wild Card";
    get_test "wheel_2_0 first" wheel_2_0 0 "Wild Card";
    get_test "wheel_2_0 second" wheel_2_0 1 "900";
    get_test "wheel_2_0 last" wheel_2_0 23 "800";
    get_test "wheel_2_0 Bankrupt" wheel_2_0 2 "Bankrupt";
    get_test "wheel_2_0 Lose a turn" wheel_2_0 11 "Lose a Turn";
    get_test "wheel_2_0 One Million" wheel_2_0 7 "One Million";
    get_test "wheel_4_0 first" wheel_4_0 0 "5000";
    get_test "wheel_4_0 second" wheel_4_0 1 "600";
    get_test "wheel_4_0 last" wheel_4_0 23 "850";
    get_test "wheel_4_0 Bankrupt" wheel_4_0 16 "Bankrupt";
    get_test "wheel_4_0 Lose a turn" wheel_4_0 8 "Lose a Turn";
    remove_wild_card_test "wheel_1_0 remove wilds" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [$500]  [$800]  \
       [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_wild_card_test "wheel_1_1 remove wilds" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [$500]  \
       [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  [One \
       Million]  [$600]  [Bankrupt]  [$850]";
    remove_wild_card_test "wheel_1_2 remove wilds" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [One \
       Million]  [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  \
       [$550]  [$800]  [$500]  [$900]  [$600]  [Bankrupt]  [$850]  \
       [$500]  [$750]  [Lose a Turn]  [$800]";
    remove_wild_card_test "wheel_1_3 remove wilds" wheel_1_3
      "[One Million]  [$550]  [Bankrupt]  [$750]  [$600]  [$500]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    remove_wild_card_test "wheel_1_4 remove wilds" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [$500]  \
       [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [One Million]  [$850]";
    remove_wild_card_test "wheel_2_0 remove wilds" wheel_2_0
      "[$500]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  [$700]  \
       [One Million]  [$700]  [$850]  [$500]  [Lose a Turn]  [$750]  \
       [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  [$3500]  \
       [$900]  [$650]  [$500]  [$800]";
    remove_wild_card_test "wheel_2_1 remove wilds" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [One Million]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [$500]  [$850]";
    remove_wild_card_test "wheel_2_2 remove wilds" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [One \
       Million]  [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  \
       [$650]  [$850]  [$600]  [$500]  [$500]  [$750]  [$900]  \
       [Bankrupt]  [$650]  [$550]  [$3500]  [$650]";
    remove_wild_card_test "wheel_2_3 remove wilds" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [One Million]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [$500]  [$550]";
    remove_wild_card_test "wheel_2_4 remove wilds" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [$500]  [$750]  \
       [$500]  [$700]  [One Million]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_million_test "wheel_1_0 remove million" wheel_1_0
      "[$500]  [$900]  [$2500]  [$500]  [$650]  [$700]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$800]  [$500]  [$700]  [Bankrupt]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
    remove_million_test "wheel_1_1 remove million" wheel_1_1
      "[$2500]  [$600]  [$700]  [$500]  [$600]  [$500]  [$750]  \
       [$700]  [Lose a Turn]  [$600]  [$650]  [$500]  [$800]  [Wild \
       Card]  [$900]  [$650]  [Bankrupt]  [$800]  [$900]  [$500]  \
       [Bankrupt]  [$600]  [Bankrupt]  [$850]";
    remove_million_test "wheel_1_2 remove million" wheel_1_2
      "[$650]  [Bankrupt]  [$700]  [$800]  [$500]  [$650]  [Bankrupt]  \
       [$750]  [$700]  [$2500]  [$650]  [$900]  [$750]  [$550]  \
       [$800]  [Wild Card]  [$900]  [$600]  [Bankrupt]  [$850]  \
       [$500]  [$750]  [Lose a Turn]  [$800]";
    remove_million_test "wheel_1_3 remove million" wheel_1_3
      "[Bankrupt]  [$550]  [Bankrupt]  [$750]  [$600]  [Wild Card]  \
       [$600]  [$850]  [$750]  [$500]  [$2500]  [$650]  [$900]  \
       [$750]  [Lose a Turn]  [$750]  [$800]  [$550]  [$600]  \
       [Bankrupt]  [$900]  [$600]  [$700]  [$850]";
    remove_million_test "wheel_1_4 remove million" wheel_1_4
      "[$500]  [Bankrupt]  [$700]  [$900]  [Lose a Turn]  [$650]  \
       [Bankrupt]  [$800]  [$650]  [$850]  [$550]  [$600]  [Wild \
       Card]  [$650]  [$750]  [$800]  [$500]  [$650]  [$2500]  [$900]  \
       [$650]  [$700]  [Bankrupt]  [$850]";
    remove_million_test "wheel_2_0 remove million" wheel_2_0
      "[Wild Card]  [$900]  [Bankrupt]  [$750]  [$800]  [$650]  \
       [$700]  [Bankrupt]  [$700]  [$850]  [$500]  [Lose a Turn]  \
       [$750]  [$600]  [$850]  [Bankrupt]  [$850]  [$500]  [$600]  \
       [$3500]  [$900]  [$650]  [$500]  [$800]";
    remove_million_test "wheel_2_1 remove million" wheel_2_1
      "[$3500]  [$500]  [Bankrupt]  [$550]  [$600]  [$650]  [Lose a \
       Turn]  [$500]  [Bankrupt]  [$800]  [$850]  [$500]  [$900]  \
       [$650]  [$550]  [$800]  [$500]  [$700]  [$900]  [Bankrupt]  \
       [$750]  [$500]  [Wild Card]  [$850]";
    remove_million_test "wheel_2_2 remove million" wheel_2_2
      "[Lose a Turn]  [$600]  [Bankrupt]  [$750]  [$650]  [Bankrupt]  \
       [$800]  [$900]  [$500]  [$750]  [$600]  [$500]  [$650]  [$850]  \
       [$600]  [Wild Card]  [$500]  [$750]  [$900]  [Bankrupt]  \
       [$650]  [$550]  [$3500]  [$650]";
    remove_million_test "wheel_2_3 remove million" wheel_2_3
      "[$500]  [Bankrupt]  [$650]  [$600]  [$700]  [$500]  [$900]  \
       [$3500]  [Bankrupt]  [$550]  [$650]  [$700]  [Bankrupt]  \
       [$850]  [$800]  [$650]  [$500]  [$750]  [Lose a Turn]  [$500]  \
       [$900]  [$550]  [Wild Card]  [$550]";
    remove_million_test "wheel_2_4 remove million" wheel_2_4
      "[$500]  [$900]  [$3500]  [$500]  [$650]  [$750]  [$900]  [Lose \
       a Turn]  [$800]  [$600]  [$500]  [Bankrupt]  [Wild Card]  \
       [$750]  [$500]  [$700]  [Bankrupt]  [$600]  [$900]  [$550]  \
       [Bankrupt]  [$600]  [$800]  [$850]";
  ]

let suite =
  "test suite for Wheel of Fortune" >::: List.flatten [ wheel_tests ]

let _ = run_test_tt_main suite