let valid_date (m : string) (d : int) : bool = if m = "Jan" || m = "Mar" || m = "May" || m = "Jul"
  || m = "Aug" || m = "Oct" || m = "Dec" then 1 <= d && d <= 31 else if m = "Apr" || m = "Jun" || m = "Sept" || m = "Nov" then 1 <= d && d <= 30 else if m = "Feb" then 1 <= d && d <= 28 else false

let rec fib n = if n = 1 then 1 else if n = 2 then 1 else fib (n-1) + fib (n-2)

let rec h n pp p = if n = 1 then p else h (n-1) p (pp + p)

let fib_fast n = if n = 0 then 0 else h n 0 1

let divide ~numerator:(x : float) ~denominator:(y : float) = x /. y

let add x y = x + y

let add5 = add 5 (**This partially applies the 5 to x in the function above*)

(**add5 7 would return 12 in utop*)
(**b/c add 5 is a function, (add 5) 1 would return 6 since you're applying 1 to the function*)

let (+/.) (a : float) (b: float) : float = (a +. b) /. 2.





