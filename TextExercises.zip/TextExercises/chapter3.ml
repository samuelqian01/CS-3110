

let rec product lst = match lst with
  | [] -> 1
  | h :: t -> h * product t

let rec concat lst = match lst with
| [] -> ""
| h :: t -> h ^ concat t

let fifth_list lst = if List.length lst < 5 then 0 else List.nth lst 4

let reverse_list (lst : int list) : int list = lst |> List.sort (Stdlib.compare) |> List.rev

let last_element lst = List.nth lst ((lst |> List.length) - 1)

let any_zeros lst = List.exists (fun x -> x = 0) lst

let rec take n lst acc = if n = 0 then acc else match lst with
| [] -> []
| h :: t -> take (n-1) t (h :: acc)

let rec drop n lst = if n = 0 then lst else match lst with
|[] -> []
| h :: t -> drop (n-1) t

let rec is_unimodal_down lst = match lst with 
| [] | [_] -> true
| h :: m :: t -> if h >= m then is_unimodal_down (m :: t) else false

let rec is_unimodal lst = match lst with 
| [] | [_] -> true
| h :: m :: t -> if h <= m then is_unimodal (m :: t) else is_unimodal_down (m :: t)

let rec print_int_list lst = if lst = [] then () else match lst with
| [] -> ()
| h :: t -> print_endline(string_of_int(h)); print_int_list t

let print_int_list' lst =
  List.iter (fun x -> print_endline (string_of_int x)) lst

type student = {first_name : string; last_name : string; gpa : float}
let create_student firstname lastname geepeeayy = {first_name = firstname; last_name = lastname; gpa = geepeeayy}

type poketype = Normal | Fire | Water

type pokemon = {name : string; hp : int; ptype : poketype}

let charizard = {name = "charizard"; hp = 78; ptype = Fire}

let safe_hd lst = match lst with
| [] -> None
| h :: _ -> Some h

let safe_tl lst = match lst with
| [] -> None
| _ :: t -> Some t

let date_before first second = match first with (y,m,d) -> match second with (y',m',d') -> if y < y' then true else if y = y' && m < m' then true else if y = y' && m = m' && d < d' then true else false 

type suit = Clubs | Hearts | Diamonds | Spades 

type rank = string * int

type card = {suit : suit; rank : int}
let ace = ("ace", 14)
let val_access tuple = match tuple with
| (x,y) -> y
let ace_of_clubs = {suit = Clubs; rank = val_access ("ace", 14)}

type quad = I | II | III | IV
type sign = Neg | Zero | Pos

let sign (x:int) : sign = if x > 0 then Pos else if x = 0 then Zero else Neg

let quadrant = fun (x,y) -> match sign x, sign y with
| Neg, Neg -> Some III
| Pos, Neg -> Some IV
| Pos, Pos -> Some I
| Neg, Pos -> Some II
| _, _ -> None

let rec earliest lst = match lst with
| [] -> None
| h :: t -> begin match earliest t with 
            | None -> Some h
            | Some h2 -> if h > h2 then Some h else Some h2 end

let norm_doer v = 
  let norm = ref 0.0 in
    for i = 0 to Array.length (v) - 1 do
      norm := !norm +. (v.(i) +. v.(i))
    done;
  sqrt(!norm)

  