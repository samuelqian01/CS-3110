open OUnit2
open Search
open Dictionary
open DictionarySet

(*****************************************************************)
(* Examples of how to create data structures *)
(*****************************************************************)

module Int = struct
  type t = int

  let compare x y =
    match Stdlib.compare x y with
    | x when x < 0 -> Dictionary.LT
    | 0 -> EQ
    | _ -> GT

  let to_string = string_of_int
end

(* Example: A list dictionary that maps ints to ints. *)
module D1 = ListDictionary.Make (Int) (Int)

(* Example: A set of strings, implemented with list dictionaries. *)
module S1 = DictionarySet.Make (StringKey.String) (ListDictionary.Make)

(* Example: A tree dictionary that maps case-insensitive strings to
   ints. *)
module D2 = TreeDictionary.Make (StringKey.CaselessString) (Int)

(* Example: A set of strings, implemented with tree dictionaries. *)
module S2 = DictionarySet.Make (StringKey.String) (TreeDictionary.Make)

(*****************************************************************)
(* Examples of how to index a directory *)
(*****************************************************************)

let data_dir_prefix = "data" ^ Filename.dir_sep

let preamble_path = data_dir_prefix ^ "preamble"

let preamble_list_idx =
  try Some (ListEngine.E.index_of_dir preamble_path) with
  | _ -> None

let preamble_tree_idx =
  try Some (TreeEngine.E.index_of_dir preamble_path) with
  | _ -> None

(*****************************************************************)
(* Test suite *)
(*****************************************************************)
module DictionaryTester (DMake : DictionaryMaker) = struct
  module Dict = DMake (StringKey.String) (StringKey.String)
  module Dict1 = DMake (Int) (Int)

  let filled_list = Dict.insert "Goodbye" "Hello" Dict.empty

  let filled_list_num = Dict1.insert 1 2 Dict1.empty

  let alphabet = Dict.insert "A" "B" (Dict.insert "B" "C" Dict.empty)

  let remove_test =
    let open Dict in
    [
      ( "Testing remove on an empty entity" >:: fun _ ->
        assert_equal (to_list (remove "Goodbye" empty)) [] );
      ( "Testing remove on a non-empty entity" >:: fun _ ->
        assert_equal (to_list (remove "Goodbye" filled_list)) [] );
    ]

  let tests =
    let open Dict in
    [
      ( "Testing is_empty on a empty entity" >:: fun _ ->
        assert_equal (is_empty empty) true );
      ( "Testing is_empty on a non-empty entity" >:: fun _ ->
        assert_equal (is_empty filled_list) false );
      ( "Testing size on an an empty entity" >:: fun _ ->
        assert_equal (size empty) 0 );
      ( "Testing size on an a non-empty entity" >:: fun _ ->
        assert_equal 1 (size filled_list) ~printer:string_of_int );
      ( "Testing insert on a empty entity" >:: fun _ ->
        assert_equal
          (to_list (insert "Goodbye" "Hello" empty))
          [ ("Goodbye", "Hello") ] );
      ( "Testing duplicate insert on a non-empty entity" >:: fun _ ->
        assert_equal
          (to_list (insert "Goodbye" "Hello" filled_list))
          [ ("Goodbye", "Hello") ] );
      ( "Testing non-duplicate insert on a non-empty entity" >:: fun _ ->
        assert_equal
          (to_list (insert "A" "Hello" filled_list))
          [ ("A", "Hello"); ("Goodbye", "Hello") ] );
      ( "Testing find on a non-empty entity" >:: fun _ ->
        assert_equal (find "Goodbye" filled_list) (Some "Hello") );
      ( "Testing find on an empty entity" >:: fun _ ->
        assert_equal (find "Goodbye" empty) None );
      ( "Testing member on a non-empty entity" >:: fun _ ->
        assert_equal (member "Goodbye" filled_list) true );
      ( "Testing member on an empty entity" >:: fun _ ->
        assert_equal (member "Goodbye" empty) false );
      ( "Testing to_list on a non-empty entity" >:: fun _ ->
        assert_equal (to_list alphabet) [ ("A", "B"); ("B", "C") ] );
      ( "Testing to_list on an empty entity" >:: fun _ ->
        assert_equal (to_list empty) [] );
      ( "Testing fold on an empty entity" >:: fun _ ->
        assert_equal
          (fold (fun x y acc -> acc @ [ (x, y) ]) [] empty)
          [] );
      ( "Testing fold on a non-empty entity" >:: fun _ ->
        assert_equal
          (fold (fun x y acc -> acc @ [ (x, y) ]) [] alphabet)
          [ ("A", "B"); ("B", "C") ] );
      ( "Testing to_string on an empty entity" >:: fun _ ->
        assert_equal (to_string empty) "{}" );
      ( "Testing to_string on a non-empty entity" >:: fun _ ->
        assert_equal "{1: 2}" (Dict1.to_string filled_list_num) );
    ]
end

module SetTester (DMake : DictionaryMaker) = struct
  module StringSet = DictionarySet.Make (StringKey.String) (DMake)
  module IntSet = DictionarySet.Make (Int) (DMake)

  let filled_list = StringSet.insert "Goodbye" StringSet.empty

  let filled_list1 =
    StringSet.insert "Hey" (StringSet.insert "Hello" StringSet.empty)

  let filled_list2 =
    StringSet.insert "Hey" (StringSet.insert "Hi" StringSet.empty)

  let filled_list3 =
    StringSet.insert "Hi" (StringSet.insert "Hey" StringSet.empty)

  let filled_list_num = IntSet.insert 1 IntSet.empty

  let remove_tests =
    let open StringSet in
    [
      ( "Testing remove on an empty set" >:: fun _ ->
        assert_equal [] (to_list (remove "Goodbye" empty)) );
      ( "Testing remove on a non empty set" >:: fun _ ->
        assert_equal [] (to_list (remove "Goodbye" filled_list)) );
    ]

  let string_tests =
    let open StringSet in
    [
      ( "Testing to_list on an empty set" >:: fun _ ->
        assert_equal [] (to_list empty) );
      ( "Testing to_list on a non empty set" >:: fun _ ->
        assert_equal [ "Hey"; "Hi" ] (to_list filled_list2) );
      ( "Testing to_list on an unordered non empty set" >:: fun _ ->
        assert_equal [ "Hey"; "Hi" ] (to_list filled_list3) );
      ( "Testing is_empty on an empty set" >:: fun _ ->
        assert_equal true (is_empty empty) );
      ( "Testing is_empty on a non empty set" >:: fun _ ->
        assert_equal false (is_empty filled_list) );
      ( "Testing size on an an empty set" >:: fun _ ->
        assert_equal 0 (size empty) );
      ( "Testing size on an a non empty set" >:: fun _ ->
        assert_equal 1 (size filled_list) );
      ( "Testing insert on an empty set" >:: fun _ ->
        assert_equal [ "Goodbye" ] (to_list (insert "Goodbye" empty)) );
      ( "Testing insert on a non empty set" >:: fun _ ->
        assert_equal [ "Goodbye"; "Hello" ]
          (to_list (insert "Hello" filled_list)) );
      ( "Testing member on a non-empty set" >:: fun _ ->
        assert_equal true (member "Goodbye" filled_list) );
      ( "Testing member on an empty set" >:: fun _ ->
        assert_equal false (member "Goodbye" empty) );
      ( "Testing union on two non-overlapping sets" >:: fun _ ->
        assert_equal
          (empty |> insert "Goodbye" |> insert "Hey" |> insert "Hello"
         |> to_list)
          (union filled_list filled_list1 |> to_list) );
      ( "Testing union on two overlapping sets" >:: fun _ ->
        assert_equal
          (empty |> insert "Hi" |> insert "Hey" |> insert "Hello"
         |> to_list)
          (union filled_list1 filled_list2 |> to_list) );
      ( "Testing intersect on two overlapping sets" >:: fun _ ->
        assert_equal
          (empty |> insert "Hey" |> to_list)
          (intersect filled_list1 filled_list2 |> to_list) );
      ( "Testing intersect on two non-overlapping sets" >:: fun _ ->
        assert_equal (empty |> to_list)
          (intersect filled_list filled_list1 |> to_list) );
      ( "Testing difference on two non-overlapping sets" >:: fun _ ->
        assert_equal
          (empty |> insert "Goodbye" |> to_list)
          (difference filled_list filled_list1 |> to_list) );
      ( "Testing difference on two overlapping sets" >:: fun _ ->
        assert_equal
          (empty |> insert "Hello" |> to_list)
          (difference filled_list1 filled_list2 |> to_list) );
      ( "Testing fold over an empty set" >:: fun _ ->
        assert_equal []
          (fold (fun element acc -> acc @ [ element ]) [] empty) );
      ( "Testing fold over a non empty set" >:: fun _ ->
        assert_equal [ "Hey"; "Hi" ]
          (fold (fun element acc -> acc @ [ element ]) [] filled_list2)
      );
      ( "Testing to_string over a non empty set" >:: fun _ ->
        assert_equal "{1}" (IntSet.to_string filled_list_num) );
      ( "Testing to_string over an empty set" >:: fun _ ->
        assert_equal "{}" (IntSet.to_string IntSet.empty) );
    ]
end

module ListTester = DictionaryTester (ListDictionary.Make)
module ListSetTester = SetTester (ListDictionary.Make)
module TreeTester = DictionaryTester (TreeDictionary.Make)
module TreeSetTester = SetTester (TreeDictionary.Make)

let suite =
  "search test suite"
  >::: List.flatten
         [
           ListTester.remove_test;
           ListTester.tests;
           ListSetTester.string_tests;
           ListSetTester.remove_tests;
           TreeTester.tests;
           TreeSetTester.string_tests;
         ]

let _ = run_test_tt_main suite
