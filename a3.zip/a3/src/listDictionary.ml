open Dictionary
open Util

module Make : DictionaryMaker =
functor
  (K : KeySig)
  (V : ValueSig)
  ->
  struct
    module Key = K
    module Value = V

    type key = K.t

    type value = V.t

    (* TODO: change type [t] from [unit] to something involving
       association lists. *)

    type t = (key * value) list
    (** AF: The association list [(k1, v1); ... ; (kn, vn)] represents
        the dictionary {(key1, val1), ... , (keyn, valn)}, where [[key1,
        val1]; ... ; [keyn, valn]] is the same association list as [(k1,
        v1); ... ; (kn, vn)] but with any duplicates removed and keys
        are sorted in order from least to greatest. The empty
        association list [] represents the empty dictionary {}.

        RI: The association list contains no duplicates. Keys are
        ordered from least to greatest in value. *)

    (**One iteration of bubble sort*)
    let rec sort_helper d acc =
      match d with
      | [] -> acc
      | [ x ] -> sort_helper [] (acc @ [ x ])
      | h :: m :: t ->
          if Key.compare (fst m) (fst h) = LT then
            sort_helper (h :: t) (acc @ [ m ])
          else sort_helper (m :: t) (acc @ [ h ])

    (**Checks that the list is in order*)
    let rec in_order d =
      match d with
      | []
      | [ _ ] ->
          true
      | h :: m :: t ->
          if Key.compare (fst m) (fst h) = LT then false
          else in_order (m :: t)

    (**Complete bubble sort*)
    let rec sort d =
      if in_order d = false then sort (sort_helper d []) else d

    let rep_ok d =
      let rec dedup (d : t) tracker (acc : t) =
        match d with
        | [] -> acc
        | h :: t ->
            if List.mem (fst h) tracker then
              dedup t tracker (List.remove_assoc (fst h) acc)
            else dedup t (fst h :: tracker) acc
      in
      if
        List.length d = List.length (dedup d [] d)
        && List.sort_uniq Stdlib.compare d = sort d
      then d
      else failwith "RI"
      [@@coverage off]

    let empty = []
    (* TODO: replace [()] with a value of your rep type [t]. Do not
       raise an exception. *)

    let is_empty d = if List.length d = 0 then true else false

    let size d = List.length d

    let rec member k d =
      match d with
      | [] -> false
      | h :: t ->
          if Key.compare k (fst h) = EQ then true else member k t

    let rec insert_helper k v d acc =
      match d with
      | [] -> acc
      | h :: t ->
          if Key.compare k (fst h) = EQ then
            insert_helper k v t (acc @ [ (k, v) ])
          else insert_helper k v t (acc @ [ h ])

    let insert k v d =
      if member k d then insert_helper k v d [] |> sort
      else d @ [ (k, v) ] |> sort

    let rec remove_helper k d acc =
      match d with
      | [] -> acc
      | h :: t ->
          if Key.compare k (fst h) = EQ then remove_helper k t acc
          else remove_helper k t (acc @ [ h ])

    let remove k d =
      if member k d then remove_helper k d [] |> sort else d

    let rec find k d =
      match d with
      | [] -> None
      | h :: t ->
          if Key.compare k (fst h) = EQ then Some (snd h) else find k t

    let to_list d = sort d

    let rec fold f init d =
      match d with
      | [] -> init
      | h :: t -> fold f (f (fst h) (snd h) init) t

    let to_string d = string_of_bindings Key.to_string Value.to_string d
  end
