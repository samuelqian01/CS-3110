open Dictionary
open Util

module type ElementSig = sig
  type t

  include Dictionary.KeySig with type t := t
end

module type Set = sig
  module Elt : ElementSig

  type elt = Elt.t

  type t

  val rep_ok : t -> t

  val empty : t

  val is_empty : t -> bool

  val size : t -> int

  val insert : elt -> t -> t

  val member : elt -> t -> bool

  val remove : elt -> t -> t

  val union : t -> t -> t

  val intersect : t -> t -> t

  val difference : t -> t -> t

  val fold : (elt -> 'acc -> 'acc) -> 'acc -> t -> 'acc

  val to_list : t -> elt list

  include Stringable with type t := t
end

module Make =
functor
  (E : ElementSig)
  (DM : DictionaryMaker)
  ->
  struct
    module Elt = E
    module D = DM (Elt) (Unit)

    type elt = Elt.t

    (* TODO: change type [t] to something involving a dictionary *)

    type t = D.t
    (** AF: The set [(k1, ()); ... ; (kn, ())] represents the dictionary
        {(key1, val1), ... , (key2, val2)} where [(key1, ()); ... ;
        [keyn, ()]] is the same set as [(k1, ()); ... ; [kn, ()]]. The
        empty set [] represents the empty dictionary {}. RI: The set
        contains no duplicates.*)

    let empty = D.empty
    (* TODO: replace [()] with a value of your rep type [t]. Do not
       raise an exception. *)

    let rec fold f init s =
      D.fold (fun key value acc -> f key acc) init s

    let is_empty s = D.is_empty s

    let size s = D.size s

    let insert x s = D.insert x () s

    let member x s = D.member x s

    let rep_ok s =
      if
        fold
          (fun element acc ->
            if member element acc then acc else insert element acc)
          empty s
        = s
      then s
      else raise (Failure "Does not satisfy RI")
      [@@coverage off]

    let remove x s = D.remove x s

    (**Accumulate all the elements of S2 before going through S1*)
    let union_helper s2 =
      fold (fun element acc -> insert element acc) empty s2

    let union s1 s2 =
      fold
        (fun element acc ->
          if member element s2 then acc else insert element acc)
        (union_helper s2) s1

    let intersect s1 s2 =
      fold
        (fun element acc ->
          if member element s2 then insert element acc else acc)
        empty s1

    let difference s1 s2 =
      fold
        (fun element acc ->
          if member element s2 then acc else insert element acc)
        empty s1

    let to_list s =
      let to_list_creator = D.to_list s in
      List.map (fun element -> fst element) to_list_creator

    let to_string d =
      string_of_list ~open_delim:"{" ~close_delim:"}" ~sep:"; "
        Elt.to_string (to_list d)
  end