open Dictionary
open Util

module Make =
functor
  (K : KeySig)
  (V : ValueSig)
  ->
  struct
    module Key = K
    module Value = V

    type key = K.t

    type value = V.t

    type color =
      | Red
      | Black

    type 'a rbtree =
      | Leaf
      | Node of color * 'a * 'a rbtree * 'a rbtree

    (* TODO: change type [t] from [unit] to something involving
       red-black trees. *)
    (* AF: TODO: The red-black tree 
    Node(color, (key1, value1), (key0, value0), (key2, value2)) 
    represents the dictionary {(k0, v0); (k1, v1); (k2, v2)} where 
    Node(color, (k1, v1), (k0, v0), (k2, v2)) is the representation in red 
    black trees.  
     * RI: TODO: The red-black tree must follow the BST and red-black 
     invariants *)
    type t = (key * value) rbtree

    (**The Okasaki red-black balancing algorithm*)
    let balance d =
      match d with
      | Black, z, Node (Red, y, Node (Red, x, a, b), c), d
      | Black, z, Node (Red, x, a, Node (Red, y, b, c)), d
      | Black, x, a, Node (Red, z, Node (Red, y, b, c), d)
      | Black, x, a, Node (Red, y, b, Node (Red, z, c, d)) ->
          Node (Red, y, Node (Black, x, a, b), Node (Black, z, c, d))
      | a, b, c, d -> Node (a, b, c, d)

    let rep_ok d =
      match d with
      | Leaf -> d
      | Node (color, v, l, r) ->
          if balance (color, v, l, r) = d then d
          else raise (Failure "Does not satisfy RI")
      [@@coverage off]

    let empty = Leaf
    (* TODO: replace [()] with a value of your rep type [t]. Do not
       raise an exception., *)

    let is_empty d =
      match d with
      | Leaf -> true
      | Node (_, _, _, _) -> false

    let rec size d =
      match d with
      | Leaf -> 0
      | Node (color, v, l, r) -> 1 + size l + size r

    let insert k v d =
      let rec ins d =
        match d with
        | Leaf -> Node (Red, (k, v), Leaf, Leaf)
        | Node (color, y, a, b) ->
            if Key.compare k (fst y) = LT then
              balance (color, y, ins a, b)
            else if Key.compare k (fst y) = GT then
              balance (color, y, a, ins b)
            else Node (color, (k, v), a, b)
      in
      match ins d with
      | Node (_, y, a, b) -> Node (Black, y, a, b)
      | Leaf -> failwith "RBT insert failed with ins returning leaf"

    let remove k d =
      raise (Failure "Unimplemented: TreeDictionary.Make.remove")

    let rec find k d =
      match d with
      | Leaf -> None
      | Node (_, v, l, r) ->
          if Key.compare k (fst v) = EQ then Some (snd v)
          else if Key.compare k (fst v) = LT then find k l
          else find k r

    let rec member k d =
      match d with
      | Leaf -> false
      | Node (_, v, l, r) ->
          if Key.compare k (fst v) = EQ then true
          else if Key.compare k (fst v) = LT then member k l
          else member k r

    let rec to_list_helper d acc =
      match d with
      | Leaf -> acc
      | Node (color, v, l, r) ->
          to_list_helper l ([ (fst v, snd v) ] @ to_list_helper r acc)

    let to_list d = to_list_helper d []

    let rec fold f acc d =
      match d with
      | Leaf -> acc
      | Node (color, v, l, r) ->
          f (fst v) (snd v) (fold f (fold f acc r) l)

    let to_string d =
      string_of_bindings Key.to_string Value.to_string (to_list d)
  end
