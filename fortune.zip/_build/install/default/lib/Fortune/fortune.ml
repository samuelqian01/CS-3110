(** @canonical Fortune.Authors *)
module Authors = Fortune__Authors


(** @canonical Fortune.Player *)
module Player = Fortune__Player


(** @canonical Fortune.Puzzle *)
module Puzzle = Fortune__Puzzle


(** @canonical Fortune.Round *)
module Round = Fortune__Round


(** @canonical Fortune.Turn *)
module Turn = Fortune__Turn


(** @canonical Fortune.Wheel *)
module Wheel = Fortune__Wheel
