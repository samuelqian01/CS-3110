type t

exception WrongGuess of char

let get_puzzle = raise (Failure "unimplemented")

let guess = raise (Failure "unimplemented")

let to_string = raise (Failure "unimplemented")

let is_solved = raise (Failure "unimplemented")