type temp = 
  | C of float
  | F of float
let kelvin = function
| F x -> 0.
| C x -> x +. 273.15



