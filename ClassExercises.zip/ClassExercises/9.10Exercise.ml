let rec last lst d = 
  match d with
  | [] -> d
  | [x] -> x
  | _ :: t -> last t d