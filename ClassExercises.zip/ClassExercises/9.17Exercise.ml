let clip_int lo hi x = 
  if x < lo then lo else if x > hi then hi else x

let clip lst = List.map clip_int lst

(**Mapping using the List.map standard library*)

let rec clip lo hi lst = function
| [] -> []
| h :: t ->