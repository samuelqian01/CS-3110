let truefalse tf = if tf = 0 then true else false;;

let truefalse tf = tf == 0;;
fun x -> x + 1;;
let inc = fun x -> x + 1;; //binding a function to a name 


