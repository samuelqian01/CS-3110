let list_max lst = match lst with
| [] -> None
| h :: t -> fun _ -> 